//
//  AppDelegate.m
//  gentlejogger
//
//  Created by mojado on 4/13/17.
//  Copyright © 2017 Sackner Wellness All rights reserved.
//

#import "AppDelegate.h"
#import "DeviceMemory.h"
@import Firebase;

@interface AppDelegate ()
{
    UIActivityIndicatorView *_loader;
    UIImageView *_loaderBackgroundView;
    
    UIView * m_showCustomView;
}
@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    NSLog(@"BUILD version:%@",[[NSBundle mainBundle] objectForInfoDictionaryKey:(NSString*)kCFBundleVersionKey]);
    // Use Firebase library to configure APIs
    [FIRApp configure];
    
    self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    UIViewController *viewController;  // determine the initial view controller here and instantiate it with [storyboard instantiateViewControllerWithIdentifier:<storyboard id>];
    if ([FIRAuth auth].currentUser) {
        // User is signed in.
        viewController = [storyboard instantiateViewControllerWithIdentifier:@"signedInAlready"];
    } else {
        viewController = [storyboard instantiateViewControllerWithIdentifier:@"signIn"];

    }
    [FIRDatabase database].persistenceEnabled = YES;
    self.window.rootViewController = viewController;
    [self.window makeKeyAndVisible];
    
    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    [self sendCMDDisConnect];
}


- (void) sendCMDDisConnect
{
    if([[DeviceMemory createInstance] isConnected]){
        NSString * seleced_device_name = [[DeviceMemory createInstance] deveice_name];
        NSString * seleced_device_uuid = [[DeviceMemory createInstance] device_uuidStr];
        
        LogicViewController * m_mainview = ((DeviceMemory*)[DeviceMemory createInstance])._mainViewController;
        BLECMD * scanCommand = [BLECMD new];
        scanCommand.cmdStr = CMDSTR_DISCONNECTDEVICE;
        scanCommand.cmd_id = 10;
        scanCommand.cmd_waitTime = 10;
        NSMutableDictionary * dict = [NSMutableDictionary new];
        [dict setObject:seleced_device_uuid forKey:@"peripheral-identifier-UUIDString"];
        [dict setObject:seleced_device_name forKey:@"peripheral-identifier-Name"];
        scanCommand.cmdData = dict;
        [m_mainview sendCMDObject:scanCommand];
        [[DeviceMemory createInstance] setIsConnected:NO];
    }
}

- (void)showLoader {
    if (_loader == nil) {
        _loader = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
        _loaderBackgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"loader_background"]];
        [self.window addSubview:_loaderBackgroundView];
        _loader.frame = CGRectMake(_loaderBackgroundView.center.x - (_loader.frame.size.width / 2),
                                   _loaderBackgroundView.center.y - (_loader.frame.size.height / 2),
                                   _loader.frame.size.width,
                                   _loader.frame.size.height);
        [_loaderBackgroundView addSubview:_loader];
    }
    [self centerLoader];
    [self.window bringSubviewToFront:_loaderBackgroundView];
    _loaderBackgroundView.hidden = NO;
    [_loader startAnimating];
    [self.window setUserInteractionEnabled:NO];
}
- (void)hideLoader {
    [self.window setUserInteractionEnabled:YES];
    [_loader stopAnimating];
    _loaderBackgroundView.hidden = YES;
}
- (void)centerLoader {
    _loaderBackgroundView.frame = CGRectMake(self.window.center.x - (_loaderBackgroundView.frame.size.width / 2),
                                             self.window.center.y - (_loaderBackgroundView.frame.size.height / 2),
                                             _loaderBackgroundView.frame.size.width,
                                             _loaderBackgroundView.frame.size.height);
    
}
- (void)showCustomView:(UIView*)view
{
    m_showCustomView = view;
    m_showCustomView.center = self.window.center;
    [self.window addSubview:m_showCustomView];
}
- (void)hideCustomView
{
    [m_showCustomView removeFromSuperview];
}


@end
