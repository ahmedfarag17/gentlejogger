//
//  ViewController.m
//  gentlejogger
//
//  Created by mojado on 4/13/17.
//  Copyright © 2017 Sackner Wellness All rights reserved.
//

#import "SetupNavigationController.h"

@interface SetupNavigationController ()

@end

@implementation SetupNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.navigationBar setHidden:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotate {
    return NO;
}
@end
