//
//  LogicViewController.h
//  RFIDRacing
//
//  Created by Robert Mosko on 2/10/17.
//  Copyright © 2017 Sackner Wellness. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BLECMD.h"
#import "BLERESP.h"

@protocol BluetoothDeviceResultDelegate

- (void)BluetoothDeviceResult:(BLERESP*)response;

@end

@interface LogicViewController : UITabBarController
@property (nonatomic, retain) id<BluetoothDeviceResultDelegate> ble_delegate;
- (void) sendCMDObject:(NSObject*)object;
- (NSMutableArray *) getDeviceList;
- (void) removeDeviceList;
- (void) removeDeviceFromUUID:(NSString *)uuid;
@end
