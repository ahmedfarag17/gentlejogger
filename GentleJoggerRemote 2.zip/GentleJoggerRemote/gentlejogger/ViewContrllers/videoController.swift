//
//  videoController.swift
//  gentlejogger
//
//  Created by hamer farag on 5/21/18.
//  Copyright © 2018 jim. All rights reserved.
//

import Foundation
import AVFoundation

class videoController : UIViewController {
    
    var Player: AVPlayer!
    var PlayerLayer: AVPlayerLayer!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let URL = Bundle.main.url(forResource: "GentleJoggerv2", withExtension: "mp4")
        Player = AVPlayer.init(url: URL!)
        
        PlayerLayer = AVPlayerLayer(player: Player)
        PlayerLayer.videoGravity = AVLayerVideoGravity.resizeAspect
        PlayerLayer.frame = view.layer.frame
        
        Player.actionAtItemEnd = AVPlayerActionAtItemEnd.none
        
        Player.play()
        view.layer.insertSublayer(PlayerLayer, at: 0)
        
        let closeBtn = UIButton();
        closeBtn.setTitle("X", for: .normal)
        
        closeBtn.setTitleColor(UIColor.black, for: .normal)
        closeBtn.backgroundColor = UIColor.clear
        closeBtn.setImage(UIImage(named: "close.png"), for: .normal)
        closeBtn.frame = CGRect(x: CGFloat(self.view.frame.width-60), y: CGFloat(30), width: CGFloat(30), height: CGFloat(30))
        //        myFirstButton.addTarget(self, action: #selector(myClass.pressed(_:)), forControlEvents: .TouchUpInside)
        closeBtn.addTarget(self, action: #selector(about(_:)), for: .touchUpInside);
        self.view.addSubview(closeBtn)
        
    }
    
    @IBAction func about(_ sender: Any) {
        Player.pause()
        self.dismiss(animated: true, completion: nil)
//        performSegue(withIdentifier: "done", sender: sender)
    }
    
    
}
