//
//  ExpandedCollectionViewCell.swift
//  gentlejogger
//
//  Created by hamer farag on 8/6/18.
//  Copyright © 2018 jim. All rights reserved.
//

import UIKit

class ExpandedCollectionViewCell: UICollectionViewCell {

    @IBOutlet var date: UILabel!
    @IBOutlet var stepsLabel: UILabel!
    @IBOutlet var timeLabel: UILabel!
    @IBOutlet var paceLabel: UILabel!
    @IBOutlet var backButton: UIButton!
    @IBOutlet var sessionWalkLabel: UILabel!
    @IBOutlet var sessionJogLabel: UILabel!
    @IBOutlet var sessionRunLabel: UILabel!
    @IBOutlet var sessionRaceLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
