//
//  DogDialog.h
//  gentlejogger
//
//  Created by mojado on 5/10/17.
//  Copyright © 2017 Sackner Wellness All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DogDialog : UIView
@property (strong, nonatomic) IBOutlet UILabel *lbl_title;
@property (strong, nonatomic) IBOutlet UIButton *onOk;
+ (UIView*) initWithXib:(NSString*)title;
@end
