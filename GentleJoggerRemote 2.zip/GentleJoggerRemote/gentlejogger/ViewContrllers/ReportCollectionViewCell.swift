//
//  ReportCollectionViewCell.swift
//  gentlejogger
//
//  Created by hamer farag on 8/6/18.
//  Copyright © 2018 jim. All rights reserved.
//

import UIKit

class ReportCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var date: UILabel!
    @IBOutlet var steps: UILabel!
    @IBOutlet var time: UILabel!
    @IBOutlet var pace: UILabel!
}
