//
//  ViewController.m
//  gentlejogger
//
//  Created by mojado on 4/13/17.
//  Copyright © 2017 Sackner Wellness All rights reserved.
//

#import "DashboardController.h"
#import "DeviceMemory.h"
#import "BLERESP.h"
#import "BLEManager.h"
#import "CommonAPI.h"
#import "SqlManager.h"
#import "AppDelegate.h"
#import "DogDialog.h"
#import <AudioToolbox/AudioToolbox.h>
@import Firebase;

#define UIColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

@interface DashboardController () <BluetoothDeviceResultDelegate, UIAlertViewDelegate> {
    
    IBOutlet UIView *mContainView;
    IBOutlet UILabel *mFEETDETECTED;
    IBOutlet UIView *pieView;

    
    IBOutlet UIButton *mWalkbtn;
    IBOutlet UIButton *mJogbtn;
    IBOutlet UIButton *mRunbtn;
    IBOutlet UIButton *mSprintbtn;
    IBOutlet UIButton *intervalButton;
    NSString *btn_interval_selected;
    
    IBOutlet UIButton *mTodaygoal5000;
    IBOutlet UIButton *mTodayTotal4000;

    UILabel *lbl_steps;
    UILabel *lbl_times;
    
    
    NSString * m_stateResponse;
    BLERESPONSE_State * state_item;
    NSMutableArray * m_stateStrings;
    int current_count;
    int currtnt_time;
    int longTouchTimerTime;
    BOOL longTouchEnd;
    BOOL sendSyncADisconnect;
    
    int firstlaunch;
    int holdCount;
    int holdTime;
    
    int stopButtunState;
    
    //Interval
    int intervalCount;
    int intervalChange;
    BOOL interval;
    NSTimer *t;
    NSTimer *restInterval;
    int intervalspeed;
    int walkCount;
    int jogCount;
    int runCount;
    int sprintCount;
    int restCount;
    int intervalCounts[5];
    
    /////
    int startStep;
    int startTime;
    BOOL nowCountingStartStep;
    BOOL nowCountingStartTime;
    int intervalStartTime;
    
    int databaseValueStep;
    int databaseValueTime;
    
    
    BOOL isReceivedD;
    BOOL isReceivedP;
    
    
    BOOL isTouchedState;
    CAShapeLayer *shapeLayer;
    CAShapeLayer *pulsatingLayer;
    
    FIRDatabaseReference *ref;
    NSString *uid;
    NSString *email;
    int walkSteps;
    int jogSteps;
    int runSteps;
    int raceSteps;
    
    
    
}

@property (weak, nonatomic) IBOutlet UIButton *btn_move;
@property (weak, nonatomic) IBOutlet UIButton *btn_stop;
@property (weak, nonatomic) IBOutlet UIButton *btn_reset;
@property (weak, nonatomic) IBOutlet UIButton *btn_interval;

@property (weak, nonatomic) IBOutlet UIButton *btn_sprint;
@property (weak, nonatomic) IBOutlet UIButton *btn_run;
@property (weak, nonatomic) IBOutlet UIButton *btn_jog;
@property (weak, nonatomic) IBOutlet UIButton *btn_walk;


@property (weak, nonatomic) IBOutlet UILabel *lbl_alert;
@property (weak, nonatomic) IBOutlet UILabel *lbl_stepsRemain;
@property (weak, nonatomic) IBOutlet UILabel *lbl_timeRemain;

@property (strong, nonatomic) IBOutlet UILabel *lbl_todayGoal;
@property (strong, nonatomic) IBOutlet UILabel *lbl_todayTotal;
@property (weak, nonatomic) IBOutlet UILabel *lbl_version;
@property (weak, nonatomic) IBOutlet UILabel *lbl_appVersion;

@end

@implementation DashboardController

- (BOOL)shouldAutorotate {
    return NO;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    pieView.frame = pieView.bounds;
    [[NSUserDefaults standardUserDefaults] setValue:[NSDate date] forKey:@"Session"];
    NSLog(@"%@", [NSDate date]);
    NSLog(@"After date;");
    [self setupCircleLayers];
    self->ref = [[FIRDatabase database] reference];
    FIRUser *user = [FIRAuth auth].currentUser;
    if (user) {
        // The user's ID, unique to the Firebase project.
        // Do NOT use this value to authenticate with your backend server,
        // if you have one. Use getTokenWithCompletion:completion: instead.
        uid = user.uid;
        email = user.email;
        // ...
    }
    walkSteps = 0;
    jogSteps = 0;
    runSteps = 0;
    raceSteps = 0;
    
    DataBaseItem * todayItem = [[SqlManager createInstance] getTodayResult];
    [[NSUserDefaults standardUserDefaults] setInteger:todayItem.steps forKey:@"StartSteps"];
    [[NSUserDefaults standardUserDefaults] setInteger:todayItem.secs forKey:@"StartTime"];
    lbl_steps = [[UILabel alloc]initWithFrame:CGRectMake(10, 50, 200, 40)];
    [lbl_steps setBackgroundColor:[UIColor clearColor]];
    [lbl_steps setText:[NSString stringWithFormat:@"%d", todayItem.steps]];
    [lbl_steps setFont:[UIFont boldSystemFontOfSize:32]];
    [lbl_steps setCenter:pieView.center];
    [lbl_steps setTextAlignment:NSTextAlignmentCenter];
    [pieView addSubview:lbl_steps];
    
//    lbl_times = [[UILabel alloc]initWithFrame:CGRectMake(lbl_steps.frame.origin.x, lbl_steps.frame.origin.y+lbl_steps.frame.size.height, 200, 40)];
//    [lbl_times setBackgroundColor:[UIColor clearColor]];
//    [lbl_times setText:@"Hi Label"];
//    [lbl_times setTextAlignment:NSTextAlignmentCenter];
//    [pieView addSubview:lbl_times];
    
    NSUserDefaults * userDefault = [NSUserDefaults standardUserDefaults];
    NSString * device_steps = [userDefault objectForKey:SYS_KEY_DEVICE_STEP];
    float percentage = (float)todayItem.steps/device_steps.intValue;
    [shapeLayer setStrokeEnd:percentage];
    CABasicAnimation *strokeEndAnimation = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
    [strokeEndAnimation setFillMode:kCAFillModeForwards];
    strokeEndAnimation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
    strokeEndAnimation.removedOnCompletion = NO;
    strokeEndAnimation.toValue = [NSNumber numberWithFloat:percentage];
    [shapeLayer addAnimation:strokeEndAnimation forKey:@"progressStatus"];
    
    firstlaunch = 0;
    longTouchEnd = YES;
    
    [self.lbl_alert setHidden:YES];
    
    m_stateResponse = @"";
    
    mContainView.layer.borderColor = [UIColorFromRGB(0x979797) CGColor];
    mContainView.layer.borderWidth = 2;
    mContainView.backgroundColor = UIColorFromRGB(0x006fba);
    
    mFEETDETECTED.layer.borderWidth = 1;
    mFEETDETECTED.layer.borderColor = [UIColorFromRGB(0x979797) CGColor];
    
    [self setFeetbtnsStatus:mWalkbtn];
    
    self.lbl_todayTotal.lineBreakMode = NSLineBreakByWordWrapping;
    self.lbl_todayTotal.textAlignment = NSTextAlignmentCenter;
    
    NSString * appVersion = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleShortVersionString"];
    NSString * buildVersion = [[NSBundle mainBundle] objectForInfoDictionaryKey:(NSString*)kCFBundleVersionKey];
    [self.lbl_appVersion setText:[NSString stringWithFormat:@"%@(%@)", appVersion, buildVersion]];

    
    
}

- (CAShapeLayer *)createCircleShapeLayer:(UIColor*)strokeColor :(UIColor*)fillColor{
    CAShapeLayer *layers = [CAShapeLayer layer];
    UIBezierPath *circularPath = [UIBezierPath bezierPath];
    [circularPath addArcWithCenter:CGPointZero radius:pieView.frame.size.height*0.4 startAngle:-(M_PI / 2) endAngle:1.5*M_PI clockwise:true];
    layers.path = circularPath.CGPath;
    layers.strokeColor = strokeColor.CGColor;
    layers.lineWidth = 10;
    layers.fillColor = fillColor.CGColor;
    layers.lineCap = kCALineCapRound;
    layers.position = pieView.center;
    return layers;
}

-(void)setupCircleLayers{
    pulsatingLayer = [self createCircleShapeLayer:UIColor.clearColor :[UIColor colorWithRed:0.05 green:0.40 blue:0.63 alpha:1.0]];
    [pieView.layer addSublayer:pulsatingLayer];
    //    animatePulsatingLayer()
    
    CAShapeLayer *trackLayer = [self createCircleShapeLayer:[UIColor colorWithRed:0.06 green:0.53 blue:0.85 alpha:1.0]:pieView.backgroundColor];
    [pieView.layer addSublayer:trackLayer];
    
    shapeLayer = [self createCircleShapeLayer:[UIColor colorWithRed:0.05 green:0.40 blue:0.63 alpha:1.0] :UIColor.clearColor];
    
    shapeLayer.strokeEnd = 0;
    [pieView.layer addSublayer:shapeLayer];
    
}

-(void) animatePulsatingLayer {
    CABasicAnimation *animation = [CABasicAnimation animation];
    [animation setKeyPath:@"transform.scale"];
    animation.toValue= [NSValue valueWithCGPoint:CGPointMake(1.2, 1.2)];
    animation.duration = 0.8;
    animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
    animation.autoreverses = true;
    animation.repeatCount = INFINITY;
    
    
    [pulsatingLayer addAnimation:animation forKey:@"animation"];
}

- (void) viewWillAppear:(BOOL)animated
{
    self.lbl_todayGoal.lineBreakMode = NSLineBreakByWordWrapping;
    self.lbl_todayGoal.textAlignment = NSTextAlignmentCenter;
    
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    NSString *textToLoad = [prefs stringForKey:@"walkPicker"];

 
    
    if(textToLoad != NULL){
        NSLog(@"--WALKING COUNT = %@", textToLoad);
        intervalCounts[0] = textToLoad.intValue;
        walkCount = textToLoad.intValue;
    }else{
        [prefs setObject:@"10" forKey:@"walkPicker"];
        intervalCounts[0] = 10;
        walkCount = 10;
    }
    textToLoad = [prefs stringForKey:@"jogPicker"];
    if(textToLoad != NULL){
        NSLog(@"--Jog COUNT = %@", textToLoad);
        intervalCounts[1] = textToLoad.intValue;
        jogCount = textToLoad.intValue;
    }else{
        [prefs setObject:@"10" forKey:@"jogPicker"];
        intervalCounts[1] = 10;
        jogCount = 10;
    }
    textToLoad = [prefs stringForKey:@"runPicker"];
    if(textToLoad != NULL ){
        NSLog(@"--Run COUNT = %@", textToLoad);
        intervalCounts[2] = textToLoad.intValue;
        runCount = textToLoad.intValue;
    }else{
        [prefs setObject:@"10" forKey:@"runPicker"];
        intervalCounts[2] = 10;
        runCount = 10;
    }
    textToLoad = [prefs stringForKey:@"racePicker"];
    if(textToLoad != NULL ){
        NSLog(@"--Sprint COUNT = %@", textToLoad);
        intervalCounts[3] = textToLoad.intValue;
        sprintCount = textToLoad.intValue;
    }else{
        [prefs setObject:@"10" forKey:@"racePicker"];
        intervalCounts[3] = 10;
        sprintCount = 10;
    }
    textToLoad = [prefs stringForKey:@"restPicker"];
    if(textToLoad != NULL){
        NSLog(@"--Rest COUNT = %@", textToLoad);
        intervalCounts[4] = textToLoad.intValue;
        //sprintCount = textToLoad.intValue;
    }else{
        [prefs setObject:@"00" forKey:@"restPicker"];
        intervalCounts[4] = 0;
        //sprintCount = 10;
    }
    
    NSUserDefaults * userDefault = [NSUserDefaults standardUserDefaults];
    NSString * device_steps = [userDefault objectForKey:SYS_KEY_DEVICE_STEP];
    
    NSString * today5000 = [NSString stringWithFormat:@"Today's Goal\n%@",device_steps];
    [self.lbl_todayGoal setText:today5000];
    
    
    DataBaseItem * todayItem = [[SqlManager createInstance] getTodayResult];
    if(todayItem){
        databaseValueStep = todayItem.steps;
        databaseValueTime = todayItem.secs;
    }else{
        databaseValueStep = 0;
        databaseValueTime = 0;
    }
    today5000 = [NSString stringWithFormat:@"Today's Total\n%d",databaseValueStep];
    [self.lbl_todayTotal setText:today5000];
    
    stopButtunState = 0;
    [[DeviceMemory createInstance] setBluetoothDeviceResultReceiver:self];
    NSString * device_name = [[DeviceMemory createInstance] deveice_name];
    NSLog(@"---------------------\ndashboard connect%@\n----------------",device_name);
#if SIM
#else
    [self sendCMDSync];
    [self sendCMDFirmwareVersion];
#endif
}

-(void)invalidate {
    _btn_interval.layer.borderColor = [[UIColor clearColor] CGColor];
    [_btn_interval setTitleColor:[UIColor colorWithRed:1.00 green:1.00 blue:1.00 alpha:1.0] forState:UIControlStateNormal];
    [_btn_interval setBackgroundColor:[UIColor colorWithRed:0.05 green:0.40 blue:0.63 alpha:1.0]];
    [_btn_interval setTitle:@"Start Interval Training" forState:normal];
    interval = FALSE;
    [t invalidate];
    t = nil;
}

- (IBAction)clickWalk:(id)sender {
    
    if(![[DeviceMemory createInstance] isConnected]){
        [[[UIAlertView alloc] initWithTitle:nil message:@"Please connect device." delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil] show];
        return;
    }
    if(sender){
        [self invalidate];
    }
    
    [self setFeetbtnsStatus:mWalkbtn];
    [self sendCMDSpeed:1];
}

- (IBAction)clickJog:(id)sender {
    if(![[DeviceMemory createInstance] isConnected]){
        [[[UIAlertView alloc] initWithTitle:nil message:@"Please connect device." delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil] show];
        return;
    }
    if(sender){
        [self invalidate];
    }
    [self setFeetbtnsStatus:mJogbtn];
    [self sendCMDSpeed:2];
}

- (IBAction)clickRun:(id)sender {
    if(![[DeviceMemory createInstance] isConnected]){
        [[[UIAlertView alloc] initWithTitle:nil message:@"Please connect device." delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil] show];
        return;
    }
    if(sender){
        [self invalidate];
    }
    [self setFeetbtnsStatus:mRunbtn];
    [self sendCMDSpeed:3];
}

- (IBAction)clickSprint:(id)sender {
    if(![[DeviceMemory createInstance] isConnected]){
        [[[UIAlertView alloc] initWithTitle:nil message:@"Please connect device." delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil] show];
        return;
    }
    if(sender){
        [self invalidate];
    }
    [self setFeetbtnsStatus:mSprintbtn];
    [self sendCMDSpeed:4];
}
- (IBAction)sendTestReset:(id)sender {
//    NSString * cmdData = @"SETBTNAME=GJMULE#";
//    [self sendCMD:cmdData :5];
}
- (IBAction)onTestSendResetFeet:(id)sender {
    //    NSString * cmdData = @"UPD=0#";
    //    [self sendCMD:cmdData :5];
}


- (IBAction)intervalSelected:(id)sender {
    if(![[DeviceMemory createInstance] isConnected]){
        [[[UIAlertView alloc] initWithTitle:nil message:@"Please connect device." delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil] show];
        return;
    }
    if(interval){
        [_btn_interval setBackgroundColor:[UIColor colorWithRed:0.05 green:0.40 blue:0.63 alpha:1.0]];
        [_btn_interval setTitle:@"Start Interval Training" forState:normal];
        interval = FALSE;
        //[self clickSprint:nil];
//        [t invalidate];
//        t = nil;
//
        NSLog(@"The button is %@",btn_interval_selected);
        if([btn_interval_selected  isEqual: @"Walk"]){
            [mWalkbtn setBackgroundColor:[UIColor colorWithRed:0.05 green:0.40 blue:0.63 alpha:1.0]];
        }else if([btn_interval_selected  isEqual: @"Jog"]){
            [mJogbtn setBackgroundColor:[UIColor colorWithRed:0.05 green:0.40 blue:0.63 alpha:1.0]];
        }else if([btn_interval_selected  isEqual: @"Run"]){
            [mRunbtn setBackgroundColor:[UIColor colorWithRed:0.05 green:0.40 blue:0.63 alpha:1.0]];
        }else if([btn_interval_selected  isEqual: @"Sprint"]){
            [mSprintbtn setBackgroundColor:[UIColor colorWithRed:0.05 green:0.40 blue:0.63 alpha:1.0]];
        }
        
//        if(stopButtunState != 0){
//            [self clickStartStop:nil];
//        }
    }else{
        int i = 0;
        for(; i<4; i++){
            if(intervalCounts[i]!=0){
                break;
            }
        }
        
        if(i == 4){
            UIAlertController * alert = [UIAlertController
                                         alertControllerWithTitle:@"No Intervals Set"
                                         message:@"All interval times set to 0 seconds. Please set at least one speed's time to greater than 0 seconds."
                                         preferredStyle:UIAlertControllerStyleAlert];
            
            //Add Buttons
            
            UIAlertAction* yesButton = [UIAlertAction
                                        actionWithTitle:@"Ok"
                                        style:UIAlertActionStyleDefault
                                        handler:^(UIAlertAction * action) {
                                            //Handle your yes please button action here
                                            
                                        }];
            [alert addAction:yesButton];
            
            [self presentViewController:alert animated:YES completion:nil];
            return;
        }
        intervalStartTime = state_item.time;
        [_btn_interval setBackgroundColor:[UIColor colorWithRed:0.17 green:0.87 blue:0.50 alpha:1.0]];
        [_btn_interval setTitle:@"End Interval Training" forState:normal];

        NSLog(@"%@", intervalButton.titleLabel.text);
        interval = TRUE;
//        t = [NSTimer scheduledTimerWithTimeInterval: 1.0
//                                             target: self
//                                           selector:@selector(onTick)
//                                           userInfo: nil repeats:YES];
        [self clickWalk:nil];
        btn_interval_selected = @"Walk";
        if(stopButtunState != 1){
            [self clickStartStop:nil];
        }
        intervalCount = 0;
        intervalChange = 0;
        intervalspeed = 1;
    }
}

-(void)restTimer{
    NSLog(@"restCOunt = %d and intervalCounts = %d",restCount,intervalCounts[4]);
    if(restCount==intervalCounts[4]){
        
        intervalspeed = 1;
        intervalStartTime = state_item.time;
        [restInterval invalidate];
        restInterval = nil;
        [self clickWalk:nil];
        btn_interval_selected = @"Walk";
        if(stopButtunState == 0){
            [self clickStartStop:nil];
        }
        NSLog(@"Clicked Walk\n");
    }else{
        restCount++;
    }
    
}


-(void)onTick{
    if(stopButtunState == 0 || !_lbl_alert.hidden){
        return;
    }
    NSLog(@"------ WalkCount : %d, -----jogCount : %d, ------runCount : %d, ------sprintCount : %d",walkCount,jogCount,runCount,sprintCount);
    int time = state_item.time-intervalStartTime;
    if((intervalspeed == 1 && time <intervalCounts[0]) || (intervalspeed == 2 && time <intervalCounts[1]) || (intervalspeed == 3 && time <intervalCounts[2]) || (intervalspeed == 4 && time <intervalCounts[3])){
        //intervalChange++;
    }else{
        intervalStartTime = state_item.time;
        //intervalspeed++;
        //intervalChange = 0;
        int i = intervalspeed;
        for (; i < 5; )
        {
            if(intervalCounts[i]==0){
                i++;
            }else{
                i++;
                break;
            }
        }
        intervalspeed=i;
        if(intervalspeed>=5){
            intervalCount++;
//            if(intervalCount == 4){
//                [self intervalSelected:nil];
//                [self performSelectorOnMainThread:@selector(showDogInterval) withObject:nil waitUntilDone:NO];
//                return;
//            }else{
                if(intervalCounts[4] != 0){
                    restCount = 0;
                    restInterval = [NSTimer scheduledTimerWithTimeInterval: 1.0
                                                                    target: self
                                                                  selector:@selector(restTimer)
                                                                  userInfo: nil repeats:YES];
                }else{
                    intervalspeed = 1;
                }
//            }
        }
        switch (intervalspeed){
            case 1:
                [self clickWalk:nil];
                if(stopButtunState == 0){
                    [self clickStartStop:nil];
                }
                btn_interval_selected = @"Walk";
                NSLog(@"Clicked Walk\n");
                break;
            case 2:
                [self clickJog:nil];
                NSLog(@"Clicked Jog\n");
                btn_interval_selected = @"Jog";
                break;
            case 3:
                [self clickRun:nil];
                NSLog(@"Clicked Run\n");
                btn_interval_selected = @"Run";
                break;
            case 4:
                [self clickSprint:nil];
                NSLog(@"Clicked Sprint\n");
                btn_interval_selected = @"Sprint";
                break;
            case 5:
                [self clickStartStop:nil];
                NSLog(@"Clicked Rest\n");
                break;
        }
    }
}



- (IBAction)clickStartStop:(id)sender {
    if(![[DeviceMemory createInstance] isConnected]){
        [[[UIAlertView alloc] initWithTitle:nil message:@"Please connect device." delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil] show];
        return;
    }
    
    isTouchedState = NO;
    
//    if(longTouchTimerTime > 0){
//        return;
//    }
    [[BLEManager createInstanceWithReceiver:self] readDataFromConnection:SYS_KEY_ALREADYCONNECTED_UUID name:SYS_KEY_ALREADYCONNECTED_NAME];

    DataBaseItem * todayItem = [[SqlManager createInstance] getTodayResult];
    if(todayItem){
        databaseValueStep = todayItem.steps;
        databaseValueTime = todayItem.secs;
    }
    else{
        databaseValueStep = 0;
        databaseValueTime = 0;
    }
    if(stopButtunState == 0)//stop
    {
        startStep = state_item.count;
        startTime = state_item.time;
        [_btn_stop setBackgroundColor:[UIColor colorWithRed:0.98 green:0.01 blue:0.01 alpha:1.0]];
        [_btn_stop setTitle:@"End Workout" forState:normal];
        stopButtunState = 1;
        [self sendCMDMoto:1];
        [self.btn_stop setSelected:YES];
        [self animatePulsatingLayer];
    }else{
        pulsatingLayer.removeAllAnimations;
        [_btn_stop setBackgroundColor:[UIColor colorWithRed:0.05 green:0.40 blue:0.63 alpha:1.0]];
        [_btn_stop setTitle:@"Start Workout" forState:normal];
        stopButtunState = 0;
        [self sendCMDMoto:0];
        [self.btn_stop setSelected:NO];
        
        int count_value = state_item.count;
        int time_value = state_item.time;
        
        int todayCount;
        int todayTime;
        
        DataBaseItem * todayItem = [[SqlManager createInstance] getTodayResult];
        if(todayItem){
            todayCount = todayItem.steps;
            todayTime = todayItem.secs;
        }else{
            todayCount = 0;
            todayTime = 0;
        }
        databaseValueStep = todayCount;
        databaseValueTime = todayTime;
//        int savedData_count = todayCount + count_value - startStep;
//        int savedData_time = todayTime + time_value - startTime;
//        NSLog(@"-------------end step sup ----------\n %d %d %d %d %d",todayCount,count_value, startStep, savedData_count, savedData_time);
        [[SqlManager createInstance] insertData:count_value time:time_value paces:((count_value) * 60.f)/time_value];
        
        //FIREBASE SEND
        NSUserDefaults * userDefault = [NSUserDefaults standardUserDefaults];
        NSDate * session = [userDefault objectForKey:@"Session"];
        int startSteps = [userDefault integerForKey:@"StartSteps"];
        int startTime = [userDefault integerForKey:@"StartTime"];
        
        NSDate *date = [NSDate date];
        NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd"];
        NSString *dateString = [dateFormatter stringFromDate:date];
        NSLog(@"DATE STRING = %@", dateString);
        [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        NSString *sessionDate = [dateFormatter stringFromDate:session];
        NSLog(@"Session STRING = %@", sessionDate);
        

        int sessionSteps = count_value-startSteps;
        int sessionTime = time_value-startTime;
        NSLog(@"Count nums: %d - %d .... Time nums : %d - %d", count_value, startSteps, time_value, startTime);
        NSDictionary *post = @{@"totalSteps":[NSString stringWithFormat:@"%d",count_value], @"totalTime": [NSString stringWithFormat:@"%d",time_value], @"pace":[NSString stringWithFormat:@"%f",((count_value) * 60.f)/time_value] };
        NSDictionary *postTwo = @{@"sessionSteps":[NSString stringWithFormat:@"%d",sessionSteps], @"sessionTime": [NSString stringWithFormat:@"%d",sessionTime], @"sessionPace":[NSString stringWithFormat:@"%f",((sessionSteps) * 60.f)/sessionTime], @"walkSteps": [NSString stringWithFormat:@"%d",walkSteps], @"jogSteps": [NSString stringWithFormat:@"%d",jogSteps], @"runSteps": [NSString stringWithFormat:@"%d",runSteps], @"raceSteps": [NSString stringWithFormat:@"%d",raceSteps] };
        [[[[ref child:@"UserHistory"] child:uid] child:dateString] updateChildValues:post];
        
        [[[[[[ref child:@"UserHistory"] child:uid] child:dateString] child:@"Sessions"] child:sessionDate] updateChildValues:postTwo];
        
    }
}
//- (IBAction)onStartButtonLongPress:(id)sender {
//    isTouchedState = YES;
//    longTouchTimerTime = 0;
//    [self performSelector:@selector(longPressTimerEvent) withObject:nil afterDelay:2];
//    NSLog(@"-------onStartButtonLongPress--------");
//}
//- (void)longPressTimerEvent
//{
//    if(isTouchedState){
//        NSLog(@"-------time out--------");
//        longTouchTimerTime = 1;
//        NSString * cmdData = @"sync=1#count=0#time=0#";
//        [self sendCMD:cmdData :5];
//    }
//}

- (void)setFeetbtnsStatus:(UIButton *) selectedBtn {
    [self setBtnDisSelected:mWalkbtn];
    [self setBtnDisSelected:mJogbtn];
    [self setBtnDisSelected:mRunbtn];
    [self setBtnDisSelected:mSprintbtn];
    
    [self setBtnSeleted:selectedBtn];
}

- (void)setBtnSeleted: (UIButton *) selectedBtn {
    NSString *which = @"";
    if(selectedBtn == mWalkbtn){
        which = @"Walk-White";
    }else if(selectedBtn == mJogbtn){
        which = @"Jog-White";
    }else if(selectedBtn == mRunbtn){
        which = @"Run-White";
    }else if(selectedBtn == mSprintbtn){
        which = @"Race-White";
    }
    
    if(interval){
        [selectedBtn setBackgroundColor:[UIColor colorWithRed:0.17 green:0.87 blue:0.50 alpha:1.0]];
    }else{
        [selectedBtn setBackgroundColor:[UIColor colorWithRed:0.05 green:0.40 blue:0.63 alpha:1.0]];
    }
    [selectedBtn setImage:[UIImage imageNamed:which] forState:normal];

}

- (void)setBtnDisSelected : (UIButton *) disselectedBtn {
    NSString *which = @"";
    if(disselectedBtn == mWalkbtn){
        which = @"Walk";
    }else if(disselectedBtn == mJogbtn){
        which = @"Jog";
    }else if(disselectedBtn == mRunbtn){
        which = @"Run";
    }else if(disselectedBtn == mSprintbtn){
        which = @"Race";
    }
    
    [disselectedBtn setImage:[UIImage imageNamed:which] forState:normal];

    [disselectedBtn setBackgroundColor:[UIColor colorWithRed:1.00 green:1.00 blue:1.00 alpha:1.0]];
    

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void) sendinitSpeedACount
{
    NSUserDefaults * userDefault = [NSUserDefaults standardUserDefaults];
    if(((NSString*)[userDefault valueForKey:USER_KEY_FIRST_NAME]).length > 0){
        NSString * userName = [userDefault valueForKey:USER_KEY_FIRST_NAME];
        [self sendNameSync:userName];
    }
    NSString * device_speed = [userDefault valueForKey:SYS_KEY_DEVICE_SPEED];
    if(device_speed){///@"Walk",@"Jog",@"Run",@"Sprint"
        if([device_speed isEqualToString:@"Walk"]) [self sendCMDSpeed:1];
        else if([device_speed isEqualToString:@"Jog"]) [self sendCMDSpeed:2];
        else if([device_speed isEqualToString:@"Run"]) [self sendCMDSpeed:3];
        else if([device_speed isEqualToString:@"Sprint"]) [self sendCMDSpeed:4];
    }
    NSString * device_steps = [userDefault valueForKey:SYS_KEY_DEVICE_STEP];
    if(device_steps){
        [self sendCMDCount:device_steps];
    }
}

#pragma mark - command
- (void) sendCMD:(NSString*)cmdData :(int)cmdIndex
{
#if SIM
#else
    
    
    NSLog(@"send Command \n %@ \n", cmdData);
    
    NSString * device_name = [[DeviceMemory createInstance] deveice_name];
    NSString * device_uuid = [[DeviceMemory createInstance] device_uuidStr];
    
    LogicViewController * m_mainview = ((DeviceMemory*)[DeviceMemory createInstance])._mainViewController;
    m_mainview.ble_delegate = self;
    BLECMD * scanCommand = [BLECMD new];
    scanCommand.cmdStr = CMDSTR_WRITEDATA;
    scanCommand.cmd_id = cmdIndex;
    scanCommand.cmd_waitTime = 40;
    NSMutableDictionary * dict = [NSMutableDictionary new];
    [dict setObject:device_uuid forKey:@"peripheral-identifier-UUIDString"];
    [dict setObject:device_name forKey:@"peripheral-identifier-Name"];
    [dict setObject:cmdData forKey:@"peripheral-write"];
    scanCommand.cmdData = dict;
    [m_mainview sendCMDObject:scanCommand];
#endif
}
- (void) sendCMDFirmwareVersion
{
    NSString * cmdData = [NSString stringWithFormat:@"SS=0#"];
    [self sendCMD:cmdData :1];
}
- (void) sendCMDMoto:(int)value
{
    NSString * cmdData = [NSString stringWithFormat:@"motor=%d#",value];
    [self sendCMD:cmdData :1];
}
- (void) sendCMDSpeed:(int)value
{
    NSString * cmdData = [NSString stringWithFormat:@"speed=%d#",value];
    [self sendCMD:cmdData :2];
}
- (void) sendCMDTarget:(int)value
{
    NSString * cmdData = [NSString stringWithFormat:@"target=%d#",value];
    [self sendCMD:cmdData :3];
}
- (void) sendCMDDate
{
    CFAbsoluteTime cfTime =  CFAbsoluteTimeGetCurrent();
    CFDateRef cfDate = CFDateCreate(kCFAllocatorDefault, cfTime);
    CFDateFormatterRef dateFormatter = CFDateFormatterCreate(kCFAllocatorDefault, CFLocaleCopyCurrent(), kCFDateFormatterFullStyle, kCFDateFormatterFullStyle);
    CFStringRef newString = CFDateFormatterCreateStringWithDate(kCFAllocatorDefault, dateFormatter, cfDate);
    CFRelease(dateFormatter);
    CFRelease(cfDate);
    
    NSString * cmdData = [NSString stringWithFormat:@"date=%@#",(__bridge NSString*)newString];
    [self sendCMD:cmdData :4];
}
- (void) sendCMDReset
{
    NSString * cmdData = @"sync=1#count=0#time=0#";
    [self sendCMD:cmdData :5];
}
- (void) sendCMDSync
{
    NSString * cmdData = @"sync=0#";
    [self sendCMD:cmdData :6];
}
- (void) sendCMDCount:(NSString*)count
{
    NSString * cmdData = [NSString stringWithFormat:@"count=%@#",count];
    [self sendCMD:cmdData :7];
}
- (void) sendNameSync:(NSString*)name
{
    NSString * cmdData = [NSString stringWithFormat:@"name=%@#",name];
    [self sendCMD:cmdData :8];
}
- (void) sendCMDConnect
{
    
    NSString * device_name = [[DeviceMemory createInstance] deveice_name];
    NSString * device_uuid = [[DeviceMemory createInstance] device_uuidStr];
    
    LogicViewController * m_mainview = ((DeviceMemory*)[DeviceMemory createInstance])._mainViewController;
    BLECMD * scanCommand = [BLECMD new];
    scanCommand.cmdStr = CMDSTR_CONNECTDEVICE;
    scanCommand.cmd_id = 555;
    scanCommand.cmd_waitTime = 10;
    NSMutableDictionary * dict = [NSMutableDictionary new];
    [dict setObject:device_uuid forKey:@"peripheral-identifier-UUIDString"];
    [dict setObject:device_name forKey:@"peripheral-identifier-Name"];
    scanCommand.cmdData = dict;
    [m_mainview sendCMDObject:scanCommand];
}
- (void) sendCMDNotifySet
{
    NSString * device_name = [[DeviceMemory createInstance] deveice_name];
    NSString * device_uuid = [[DeviceMemory createInstance] device_uuidStr];
    
    LogicViewController * m_mainview = ((DeviceMemory*)[DeviceMemory createInstance])._mainViewController;
    m_mainview.ble_delegate = self;
    BLECMD * scanCommand = [BLECMD new];
    scanCommand.cmdStr = CMDSTR_NOTIFY;
    scanCommand.cmd_id = 100;
    scanCommand.cmd_waitTime = 40;
    NSMutableDictionary * dict = [NSMutableDictionary new];
    [dict setObject:device_uuid forKey:@"peripheral-identifier-UUIDString"];
    [dict setObject:device_name forKey:@"peripheral-identifier-Name"];
    scanCommand.cmdData = dict;
    [m_mainview sendCMDObject:scanCommand];
    
    [[DeviceMemory createInstance] setIsConnected:YES];
}

- (void) updateState{
    NSUserDefaults * defaultSaver = [NSUserDefaults standardUserDefaults];
    int count_value = (int)[defaultSaver integerForKey:@"KEY_COUNT"];
    int time_value = (int)[defaultSaver integerForKey:@"KEY_TIME"];
    
    int todayCount;
    int todayTime;
    
    DataBaseItem * todayItem = [[SqlManager createInstance] getTodayResult];
    if(todayItem){
        todayCount = todayItem.steps;
        todayTime = todayItem.secs;
    }else{
        todayCount = 0;
        todayTime = 0;
    }
    databaseValueStep = todayCount;
    databaseValueTime = todayTime;
    if(count_value == 0 || time_value == 0){
        return;
    }
    
    int savedData_count = todayCount + count_value - startStep;
    
    if(databaseValueStep > 0 && count_value>startStep && startStep > 0){
        //        savedData_count = savedData_count + 1;
    }
    
    int savedData_time = todayTime + time_value - startTime;
    
    if(databaseValueTime > 0 && time_value>startTime && startTime > 0){
        //        savedData_time = savedData_time + 1;
    }
    
    databaseValueStep = savedData_count;
    databaseValueTime = savedData_time;
    
    if(savedData_count > 0 && savedData_time > 0){
        NSLog(@"-------------end step ----------\n %d %d %d %d %d",todayCount,count_value, startStep, savedData_count, savedData_time);
        [[SqlManager createInstance] insertData:savedData_count time:savedData_time paces:(savedData_count * 60.f)/savedData_time];
        
        NSString * today5000 = [NSString stringWithFormat:@"Today's Total\n%d",savedData_count];
        [self.lbl_todayTotal setText:today5000];
    }
    isReceivedD = NO;
    isReceivedP = NO;
    
    if(interval){
        NSLog(@"Interval Speed = %d .... \nDatabaseValueTime = %d .... \nintervalStartTime = %d ..... \n IntervalCounts[] = %d", intervalspeed, databaseValueTime, intervalStartTime, intervalCounts[intervalspeed-1]);
        if((intervalspeed == 1 && databaseValueTime == intervalStartTime + intervalCounts[0]) || (intervalspeed == 2 && databaseValueTime == intervalStartTime + intervalCounts[1]) || (intervalspeed == 3 && databaseValueTime == intervalStartTime + intervalCounts[2]) || (intervalspeed == 4 && databaseValueTime == intervalStartTime + intervalCounts[3])) {
            //interval reached, switch to next interval
            int i = intervalspeed;
            for (; i < 5; )
            {
                if(intervalCounts[i]==0){
                    i++;
                }else{
                    i++;
                    break;
                }
            }
            intervalspeed=i;
            if(intervalspeed>=5){
                intervalspeed = 1;
               
            }
            intervalStartTime = databaseValueTime;
            switch (intervalspeed){
                case 1:
                    [self clickWalk:nil];
                    if(stopButtunState == 0){
                        [self clickStartStop:nil];
                    }
                    btn_interval_selected = @"Walk";
                    NSLog(@"Clicked Walk\n");
                    break;
                case 2:
                    [self clickJog:nil];
                    NSLog(@"Clicked Jog\n");
                    btn_interval_selected = @"Jog";
                    break;
                case 3:
                    [self clickRun:nil];
                    NSLog(@"Clicked Run\n");
                    btn_interval_selected = @"Run";
                    break;
                case 4:
                    [self clickSprint:nil];
                    NSLog(@"Clicked Sprint\n");
                    btn_interval_selected = @"Sprint";
                    break;
                case 5:
                    [self clickStartStop:nil];
                    NSLog(@"Clicked Rest\n");
                    break;
            }
        }
    }
    
}

- (void) updateTodayTotal:(int)steps
{
//    NSString * today5000 = [NSString stringWithFormat:@"Today's Total\n%d",steps];
//    [self.lbl_todayTotal setText:today5000];
    
    NSLog(@"-----------\ntoday total %d-------\n",steps);
    
    NSUserDefaults * userDefault = [NSUserDefaults standardUserDefaults];
    NSString * device_steps = [userDefault objectForKey:SYS_KEY_DEVICE_STEP];
    int count_value = state_item.count;
    int time_value = state_item.time;
    
    [[SqlManager createInstance] insertData:count_value time:time_value paces:((count_value) * 60.f)/time_value];

    if(steps == device_steps.intValue){
        [self performSelectorOnMainThread:@selector(showDogDialog) withObject:nil waitUntilDone:NO];
    }else{
        NSLog(@"not equal");
        float percentage = (float)steps/device_steps.intValue;
        NSLog(@"Percentage = %f ----- Steps = %d ------ Device.Steps = %d ----- %d", percentage, steps, device_steps.intValue, steps/device_steps.intValue);
        if(percentage>=1){
            NSLog(@"greater than 1");

            return;
        }
        [shapeLayer setStrokeEnd:percentage];
        CABasicAnimation *strokeEndAnimation = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
        [strokeEndAnimation setFillMode:kCAFillModeForwards];
        strokeEndAnimation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
        strokeEndAnimation.removedOnCompletion = NO;
        //strokeEndAnimation.fromValue = [NSNumber numberWithFloat:percentage-0.1f];
        strokeEndAnimation.toValue = [NSNumber numberWithFloat:percentage];
        
        [shapeLayer addAnimation:strokeEndAnimation forKey:@"progressStatus"];
    }
}

- (void) showDogInterval
{
    //[self clickStartStop:nil];
    //NSUserDefaults * userDefault = [NSUserDefaults standardUserDefaults];
    //NSString * device_steps = [userDefault objectForKey:SYS_KEY_DEVICE_STEP];
    NSString * dialogString = [NSString stringWithFormat:@"Congratulations!\nYou've completed your interval training! Current step count : %d", state_item.count];
    
    UIView * subView = [DogDialog initWithXib:dialogString];
    subView.center = self.tabBarController.view.center;
    [self.tabBarController.view addSubview:subView];
}

- (void) showDogDialog
{
    //[self clickStartStop:nil];
    NSUserDefaults * userDefault = [NSUserDefaults standardUserDefaults];
    NSString * device_steps = [userDefault objectForKey:SYS_KEY_DEVICE_STEP];
    NSString * dialogString = [NSString stringWithFormat:@"Congratulations!\nYou've reached your goal of\n%@ steps today.",device_steps];
    
    UIView * subView = [DogDialog initWithXib:dialogString];
    subView.center = self.tabBarController.view.center;
    [self.tabBarController.view addSubview:subView];
}

- (void) parseString:(NSString*)str
{
    if(!state_item)
        state_item  = [BLERESPONSE_State new];
    NSArray * subSpliteArray = [str componentsSeparatedByString:@"="];
    NSString * value = @"";
    NSUserDefaults * userDefault = [NSUserDefaults standardUserDefaults];
    NSString * device_steps = [userDefault objectForKey:SYS_KEY_DEVICE_STEP];
    if(subSpliteArray.count > 1){
        value = [subSpliteArray objectAtIndex:1];
    }
    if(value && value.length > 0){
        if([[subSpliteArray objectAtIndex:0] isEqualToString:@"t"]){
            state_item.time = value.intValue;
            if(state_item.time == 0){
                nowCountingStartTime = NO;
            }
            NSLog(@"First Launch Time = %d",firstlaunch);

            if(firstlaunch<2){
                
                
                    if(firstlaunch == 0){
                        holdTime = state_item.time+databaseValueTime;
                        NSLog(@"Hold time = %d", holdTime);
                    }else{
                        
                        if(databaseValueStep <= state_item.count+2 && databaseValueStep >= state_item.count-2){
                            NSString *combString = [NSString stringWithFormat:@"%d", state_item.time];
                            NSString * cmdData = [NSString stringWithFormat:@"%@%@", @"sync=1#time=", combString];
                            [self sendCMD:cmdData :5];
                            [self->lbl_times setText:[CommonAPI convertSecondToTime:state_item.time]];
                            firstlaunch++;
                            return;
                        }
                        NSLog(@"Inserting in Time: %d for the count and %d for the time",holdCount, (state_item.time+databaseValueTime));
                        [[SqlManager createInstance] insertData:holdCount time:state_item.time+databaseValueTime paces:(holdCount * 60.f)/(state_item.time+databaseValueTime)];
                        int comb = state_item.count+databaseValueStep;
                        NSString *combString = [NSString stringWithFormat:@"%d",comb];
                        NSString * cmdData = [NSString stringWithFormat:@"%@%@", @"sync=1#count=", combString];
                        [self sendCMD:cmdData :5];
                        comb = state_item.time+databaseValueTime;
                        combString = [NSString stringWithFormat:@"%d",comb];
                        cmdData = [NSString stringWithFormat:@"%@%@", @"sync=1#time=", combString];
                        [self sendCMD:cmdData :5];
                        [self->lbl_times setText:[CommonAPI convertSecondToTime:(state_item.time+databaseValueTime)]];
                        [self->lbl_steps setText:[NSString stringWithFormat:@"%d",(state_item.count+databaseValueStep)]];
                    }
                
                
                    firstlaunch++;
                    return;
                
            }
            [self->lbl_times setText:[CommonAPI convertSecondToTime:(state_item.time)]];
            
            if(!nowCountingStartTime){
                startTime = state_item.time;
                nowCountingStartTime = YES;
                
                [[NSUserDefaults standardUserDefaults] setInteger:0 forKey:@"KEY_TIME"];
            }
            int todayTime = databaseValueTime + state_item.time - startTime;
            //            if(databaseValueTime > 0 && state_item.time>startTime && startTime > 0)
            //                todayTime = todayTime + 1;
            if(todayTime > 0 && state_item.time>startTime){
                NSLog(@"-------------running time ----------\n %d %d %d %d",databaseValueTime,state_item.time, startTime, todayTime);
            }
            
        }else if([[subSpliteArray objectAtIndex:0] isEqualToString:@"c"]){
            state_item.count = value.intValue;
            if(state_item.count == 0){
                nowCountingStartStep = NO;
            }
            NSLog(@"First Launch In count= %d",firstlaunch);
            if(firstlaunch<2){
                
                if(state_item.count == databaseValueStep){
                    
                    
                }else{
                    
                    if(firstlaunch == 0){
                        holdCount = state_item.count+databaseValueStep;
                    }else{
                        NSLog(@"Inserting %d for the count and %d for the time, %d for state and %d for database",(state_item.count+databaseValueStep), holdTime, state_item.count, databaseValueStep);
                        [[SqlManager createInstance] insertData:(state_item.count+databaseValueStep) time:holdTime paces:((state_item.count+databaseValueStep) * 60.f)/holdTime];
                        int comb = state_item.count+databaseValueStep;
                        NSString *combString = [NSString stringWithFormat:@"%d",comb];
                        NSString * cmdData = [NSString stringWithFormat:@"%@%@", @"sync=1#count=", combString];
                        [self sendCMD:cmdData :5];
                        comb = state_item.time+databaseValueTime;
                        combString = [NSString stringWithFormat:@"%d",comb];
                        cmdData = [NSString stringWithFormat:@"%@%@", @"sync=1#time=", combString];
                        [self sendCMD:cmdData :5];
                        [self->lbl_times setText:[CommonAPI convertSecondToTime:(state_item.time+databaseValueTime)]];
                        [self->lbl_steps setText:[NSString stringWithFormat:@"%d",(state_item.count+databaseValueStep)]];

                    }
                    
                    

                    firstlaunch++;
                    return;
                }
            }
            switch (state_item.speed) {
                case 1:
                    walkSteps++;
                    break;
                case 2:
                    jogSteps++;
                    break;
                case 3:
                    runSteps++;
                    break;
                case 4:
                    raceSteps++;
                    break;
                    
                default:
                    break;
            }
            [self->lbl_steps setText:[NSString stringWithFormat:@"%d",state_item.count]];
            
            if(!nowCountingStartStep){
                startStep = state_item.count;
                nowCountingStartStep = YES;
                [[NSUserDefaults standardUserDefaults] setInteger:0 forKey:@"KEY_COUNT"];
            }
            int todayTotal = databaseValueStep + state_item.count - startStep;
            if(startStep > 0)
                todayTotal += 1;
            //            if(databaseValueStep > 0 && state_item.count>startStep && startStep > 0)
            //                todayTotal = todayTotal + 1;
            if(todayTotal > 0 && state_item.count>startStep){
                NSLog(@"-------------running step ----------\n %d %d %d %d",databaseValueStep,state_item.count, startStep, todayTotal);
                [self updateTodayTotal:todayTotal];
            }
        }else if([[subSpliteArray objectAtIndex:0] isEqualToString:@"d"]){
//            state_item.duration = value.intValue + startTime;
            [CommonAPI setTodayTimeACount:state_item.duration];
//            nowCountingStartTime = NO;
            isReceivedD = YES;
            if(nowCountingStartTime && isReceivedD && isReceivedP) {
                state_item.duration = value.intValue + startTime;
                //[self updateState];
            }
            nowCountingStartTime = NO;
        }else if([[subSpliteArray objectAtIndex:0] isEqualToString:@"p"]){
            state_item.steps = value.intValue + startStep;
            [CommonAPI setTodayCountATime:state_item.steps];
//            nowCountingStartStep = NO;
            isReceivedP = YES;
//            databaseValueStep += current_count;
            if(nowCountingStartStep && isReceivedD && isReceivedP) {
                databaseValueStep += current_count;
                //[self updateState];
            }
            nowCountingStartStep = NO;
        }else if([[subSpliteArray objectAtIndex:0] isEqualToString:@"r"]){
            //            if(value.intValue == 2){
            [self sendCMDSync];
            //            }
        }else if([[subSpliteArray objectAtIndex:0] isEqualToString:@"s"]){
            state_item.speed = value.intValue;
            if(state_item.speed == 1) {
                [self setFeetbtnsStatus:mWalkbtn];
            }else if(state_item.speed == 2){
                [self setFeetbtnsStatus:mJogbtn];
            }else if(state_item.speed == 3){
                [self setFeetbtnsStatus:mRunbtn];
            }else if(state_item.speed == 4){
                [self setFeetbtnsStatus:mSprintbtn];
            }
        }else if([[subSpliteArray objectAtIndex:0] isEqualToString:@"m"]){
            state_item.motor = value.intValue;
            if(state_item.motor == 1){/*[self.btn_move setSelected:YES];[self.btn_stop setSelected:NO];*/
                stopButtunState = 1;
                [self.btn_stop setSelected:YES];
            }
            else if(state_item.motor == 0){/*[self.btn_move setSelected:NO];[self.btn_stop setSelected:YES];*/ stopButtunState = 0;
                [self.btn_stop setSelected:NO];
            }
            
        }else if([[subSpliteArray objectAtIndex:0] isEqualToString:@"a"]){
            state_item.avgspeed = value.intValue;
            
        }else if([[subSpliteArray objectAtIndex:0] isEqualToString:@"u"]){
            state_item.powerUp = value.intValue;
        }else if([[subSpliteArray objectAtIndex:0] isEqualToString:@"xt"]){
            int m_value = value.intValue;
            if(m_value == 0){
                [self.lbl_timeRemain setText:@"Time"];
            }else{
            }
        }else if([[subSpliteArray objectAtIndex:0] isEqualToString:@"xs"]){
            int m_value = value.intValue;
            if(m_value == 0){
                [self.lbl_alert setHidden:YES];
            }else{
//                [self.lbl_stepsRemain setText:@"Steps Left"];
            }
        }else if([[subSpliteArray objectAtIndex:0] isEqualToString:@"xa"]){
            if(![value isEqualToString:@" "]){
                AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
                [self.lbl_alert setHidden:NO];
            }else
                [self.lbl_alert setHidden:YES];
            [self.lbl_alert setText:value];
        }else if([[subSpliteArray objectAtIndex:0] isEqualToString:@"x"]){
            [self.lbl_alert setText:value];
        }else if([[subSpliteArray objectAtIndex:0] isEqualToString:@"z"]){
            /////////
            NSLog(@"version string = %@", value);
            if(value && value.length > 0){
                NSArray * values = [value componentsSeparatedByString:@","];
                for(NSString * subString in values){
                    if([subString containsString:@"Version:"] && [subString containsString:@"thresh"]){
                        NSString * versionString = [[subString componentsSeparatedByString:@"Version:"] lastObject];
                        versionString = [[versionString componentsSeparatedByString:@"thresh"] firstObject];
                        [self.lbl_version setText:versionString];
                    }
                }
            }
        }
    }
}

- (void)BluetoothDeviceResult:(BLERESP*)response
{
    if([response.function isEqualToString:@"didUpdateValueForCharacteristic"]){
        if(!response.message)
            return;
        m_stateResponse = [m_stateResponse stringByAppendingString:response.message];
        
        NSMutableArray * spliteArray = [[NSMutableArray alloc] initWithArray:[m_stateResponse componentsSeparatedByString:@"#"]];
        NSString * lastString = [spliteArray lastObject];
        for(int i=0;i<[spliteArray count]-1;i++){
            NSString * subString = [spliteArray objectAtIndex:i];
            [self parseString:subString];
        }
        m_stateResponse = @"";
        if(lastString && ![lastString isEqualToString:@""]){
            m_stateResponse = lastString;
        }
    }else if([response.function isEqualToString:@"didDisconnectPeripheral"]){
        [[DeviceMemory createInstance] setIsConnected:NO];
        
//        [self sendCMDConnect];
        sendSyncADisconnect = FALSE;
        
        AppDelegate * appdelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
        [appdelegate showLoader];
        
        [self performSelector:@selector(sendCMDConnect) withObject:nil afterDelay:5];
//        [self sendCMDConnect];
        
    }else if([response.function isEqualToString:@"didConnectPeripheral"]){
        AppDelegate * appdelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
        [appdelegate hideLoader];
        if(response.messageType == 0)/// return connect error
        {
            [[[UIAlertView alloc] initWithTitle:nil message:@"Device connect fail." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil] show];
            
            [[DeviceMemory createInstance] setIsConnected:NO];
        }else{
            if(!sendSyncADisconnect){
                [self performSelector:@selector(reconnectFunctions) withObject:nil afterDelay:0.5];
                sendSyncADisconnect = YES;
                [[DeviceMemory createInstance] setIsConnected:YES];
            }
        }
    }else if([response.function isEqualToString:@"endCMD"]){
        if([response.message intValue] == 555){
            AppDelegate * appdelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
            [appdelegate hideLoader];
            NSString * device_name = [[DeviceMemory createInstance] deveice_name];
            NSString * device_uuid = [[DeviceMemory createInstance] device_uuidStr];
            [[[UIAlertView alloc] initWithTitle:nil message:[NSString stringWithFormat:@"Can’t find Gentle Jogger %@",[device_name substringFromIndex:2]] delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil] show];
            [[DeviceMemory createInstance] setIsConnected:NO];
            LogicViewController * m_mainview = ((DeviceMemory*)[DeviceMemory createInstance])._mainViewController;
            [m_mainview removeDeviceFromUUID:device_uuid];
        
        }
    }
    
}
- (void) reconnectFunctions
{
    [self sendCMDNotifySet];
    [self sendCMDSync];
    if(state_item){
        int count = state_item.count;
        int time = state_item.time;
        int speed = state_item.speed;
        
        NSString * commandStrig = [NSString stringWithFormat:@"speed=%d#count=%d#time=%d#",speed ,count, time];
        NSLog(@"Reconnect command: %@",commandStrig);
        [self sendCMD:commandStrig :40];
    }
    [self sendCMDFirmwareVersion];
}
- (void) alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 0){
        [self.navigationController.tabBarController setSelectedIndex:0];
    }else{
        
    }
}
@end
