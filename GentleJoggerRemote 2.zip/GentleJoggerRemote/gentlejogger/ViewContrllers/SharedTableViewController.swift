//
//  SharedTableViewController.swift
//  gentlejogger
//
//  Created by hamer farag on 1/24/19.
//  Copyright © 2019 jim. All rights reserved.
//

import UIKit
import Firebase

protocol SomeProtocol {
    
    func refresh()
}

class SharedTableViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, SomeProtocol {

    @IBOutlet var userTableView: UITableView!
    var count : Int = 0;
    var data: [String] = [];
    var completed = false;
    var selectedRow : Int = -1;
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var ref: DatabaseReference!
        
        ref = Database.database().reference()
        
        let userID = Auth.auth().currentUser?.uid
        
        ref.child("SharedUsers").child(userID!).observeSingleEvent(of: .value, with: { (snapshot) in
            // Get user value
            print(snapshot.exists());
            if(snapshot.exists()){
                
                for (key,value) in (snapshot.value as? NSDictionary)!{
                    let email = (key as! String).replacingOccurrences(of: ",", with: ".");
                    self.data.append(email);
                }
            }
            self.data = self.data.sorted()
            let defaults = UserDefaults.standard
            defaults.set(self.data, forKey: "sharedUsers");
            
            self.userTableView?.reloadData()
            print("Completed in viewDidLoad = ", self.completed)
            self.completed = true;

        }) { (error) in
            print(error.localizedDescription)
        }
    }
    
    func refresh() {
        print("Completed in viewDidAppear = ", completed)
        if(completed){
            let defaults = UserDefaults.standard
            if let data2 = defaults.array(forKey: "sharedUsers") {
                self.data = data2 as! [String];
            }
            
            print(self.data);
            
            self.userTableView?.reloadData()
        }
    }
    
    
    
    func numberOfSections(in tableView: UITableView) -> Int{
        return 1;
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.data.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //create tableviewcell and return it
        let cell = tableView.dequeueReusableCell(withIdentifier: "tableCell", for: indexPath) as! SharedTableViewCell
        let index:Int = (indexPath.row)
        print(data[index]);
        cell.email.text = data[index]
        
        return cell; //self.data[indexPath.item];
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if (editingStyle == .delete) {
            // handle delete (by removing the data from your array and updating the tableview)
            var ref: DatabaseReference!
            
            ref = Database.database().reference()
            
            let userID = Auth.auth().currentUser?.uid
           ref.child("SharedUsers").child(userID!).child(data[indexPath.row].replacingOccurrences(of: ".", with: ",")).removeValue()
            data.remove(at: indexPath.row)
            let defaults = UserDefaults.standard
            defaults.set(data, forKey: "sharedUsers");
            tableView.reloadData()
            print("Delete!")
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedRow = indexPath.row
        performSegue(withIdentifier: "toExpandedView", sender: nil)

    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destVC = segue.destination as? PopUpViewController{
            destVC.delegate = self 
        }
        if(selectedRow>=0){
            let defaults = UserDefaults.standard
            defaults.set(data[selectedRow].replacingOccurrences(of: ".", with: ","), forKey: "passedUser");
        }
        print("Set the item")

    }
    


    // MARK: - Table view data source


    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
   
    */

}
