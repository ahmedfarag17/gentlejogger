//
//  RegisterViewController.m
//  gentlejogger
//
//  Created by hamer farag on 8/1/18.
//  Copyright © 2018 jim. All rights reserved.
//

#import "RegisterViewController.h"
@import Firebase;

@interface RegisterViewController () <UITextFieldDelegate>
@property (strong, nonatomic) IBOutlet UITextField *email;
@property (strong, nonatomic) IBOutlet UITextField *password;
@property (strong, nonatomic) IBOutlet UITextField *confirmPassword;
@property (strong, nonatomic) IBOutlet UILabel *errLabel;

@end

@implementation RegisterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
     [_errLabel setHidden:YES];
    self.email.delegate = self;
    self.password.delegate = self;
    self.confirmPassword.delegate = self;
    NSNumber *orientationValue = [NSNumber numberWithInt:UIInterfaceOrientationPortrait];
    [[UIDevice currentDevice] setValue: orientationValue forKey:@"orientation"];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    
    [self.view addGestureRecognizer:tap];
    [_errLabel setAdjustsFontSizeToFitWidth:NO];
}

- (BOOL) textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    
    return YES;
}

-(void)dismissKeyboard
{
    [_email resignFirstResponder];
    [_password resignFirstResponder];
    [_confirmPassword resignFirstResponder];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)backToLogin:(id)sender {
     [self.navigationController popViewControllerAnimated:YES];
}

- (BOOL)shouldAutorotate {
    return NO;
}

- (IBAction)signUp:(id)sender {
    [_errLabel setHidden:YES];

    NSString *emailstring = [_email text];
    NSString *passString = [_password text];
    NSString *confPassString = [_confirmPassword text];
    
    if(!emailstring || [emailstring length] == 0 || !passString || [passString length] == 0 || ![self validateEmailWithString:emailstring]){
        [_errLabel setText:@"Please enter an email and password"];
        [_errLabel setHidden:NO];    return;
    }
    
    if([passString isEqualToString:confPassString] != 1){
        //NSLog(@"%@ and %@",passString, confPassString);
        [_errLabel setText:@"The passwords do not match."];
        [_errLabel setHidden:NO];
        return;
    }
    
    
    [[FIRAuth auth] createUserWithEmail:emailstring
                               password:passString
                             completion:^(FIRAuthDataResult * _Nullable authResult,
                                          NSError * _Nullable error) {
                                 if (error) {
                                     NSString *err;
                                     if(error == FIRAuthErrorCodeEmailAlreadyInUse){
                                         err = @"Email is already in use.";
                                     }else if(error == FIRAuthErrorCodeNetworkError){
                                         err = @"No Internet Connection";
                                     }else if(error == FIRAuthErrorCodeWeakPassword){
                                         err = @"Password is too weak.";
                                         NSLog(error.localizedDescription);
                                     }else{
                                         err = error.localizedDescription;
                                     }
                                     [_errLabel setText:err];
                                     [_errLabel setHidden:NO];
                                     return;
                                 }
                                 NSLog(@"User Signed up");

                                 [self performSegueWithIdentifier:@"signedIn" sender:self];
                             }];
    
    
    //Segue to app
    
}
- (BOOL)validateEmailWithString:(NSString*)email
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


@end
