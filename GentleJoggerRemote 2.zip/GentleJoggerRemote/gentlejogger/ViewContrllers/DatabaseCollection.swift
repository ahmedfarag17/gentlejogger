//
//  DatabaseCollection.swift
//  gentlejogger
//
//  Created by hamer farag on 8/6/18.
//  Copyright © 2018 jim. All rights reserved.
//

import Foundation

struct DatabaseCollection {
    let date : String;
    let secs : String;
    let time : String;
    let pace : String;
    var sessions : [Session];
    
    init(date: String, dictionary : Dictionary<String,Any>){
        self.date = date;
        self.secs = dictionary["totalSteps"] as! String;
        self.time = dictionary["totalTime"] as! String;
        let fullPace = dictionary["pace"] as! String;
        if let endIndex = fullPace.range(of: ".")?.lowerBound {
            self.pace = String(fullPace[..<endIndex])
        }else{
            self.pace = fullPace;
        }
        self.sessions = [];
        let dict:Dictionary<String,Any> = dictionary["Sessions"] as! Dictionary;
        for (key, value) in dict {
            self.sessions.append(Session.init(time: key, dictionary: value as! Dictionary<String, String>))
        }
    }
}
