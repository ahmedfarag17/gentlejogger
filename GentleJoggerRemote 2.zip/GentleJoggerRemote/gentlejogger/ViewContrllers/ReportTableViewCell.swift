//
//  ReportTableViewCell.swift
//  gentlejogger
//
//  Created by hamer farag on 2/22/19.
//  Copyright © 2019 jim. All rights reserved.
//

import UIKit

class ReportTableViewCell: UITableViewCell {

    @IBOutlet var stepsLabel: UILabel!
    
    @IBOutlet var progressView: UIView!
    
    var percent : Float = 0.0;
    
    func create() {
        let shapelayer = CAShapeLayer()
        let circularPath = UIBezierPath(arcCenter: progressView.center, radius: progressView.frame.height/3, startAngle: -CGFloat.pi/2, endAngle: ((2*CGFloat.pi)-CGFloat.pi/2), clockwise: true)
        shapelayer.path = circularPath.cgPath
        shapelayer.fillColor = UIColor.clear.cgColor
        shapelayer.lineWidth = 3
        shapelayer.lineCap = kCALineCapRound
        if(percent<0.33){
            shapelayer.strokeColor = UIColor(red:0.78, green:0.13, blue:0.25, alpha:1.0).cgColor
        }else if(percent<0.66){
            shapelayer.strokeColor = UIColor(red:0.97, green:0.98, blue:0.32, alpha:1.0).cgColor
        }else{
            shapelayer.strokeColor = UIColor(red:0.12, green:0.98, blue:0.65, alpha:1.0).cgColor

        }
        print("precent = ",percent)
        shapelayer.strokeEnd = CGFloat(percent)
        
        progressView.layer.addSublayer(shapelayer)
        
        let percentlabel = UILabel(frame: CGRect(x: 0, y: 0, width: progressView.frame.width, height: 21))
        percentlabel.center = progressView.center
        percentlabel.text = String(Int(percent*100)) + "%";
        percentlabel.font = percentlabel.font.withSize(9)
        percentlabel.textAlignment = .center
        
        progressView.addSubview(percentlabel)
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        for view in progressView.subviews{
            view.removeFromSuperview()
        }
        progressView.layer.sublayers?.forEach { $0.removeFromSuperlayer() }

    }
 
}
