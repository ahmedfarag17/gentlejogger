//
//  ExpandedTableViewCell.swift
//  gentlejogger
//
//  Created by hamer farag on 2/25/19.
//  Copyright © 2019 jim. All rights reserved.
//

import UIKit

class ExpandedTableViewCell: UITableViewCell {

    @IBOutlet var sessionDateTime: UILabel!
    @IBOutlet var sessionStepCount: UILabel!
    @IBOutlet var walkCount: UILabel!
    @IBOutlet var jogCount: UILabel!
    @IBOutlet var runCount: UILabel!
    @IBOutlet var raceCount: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
