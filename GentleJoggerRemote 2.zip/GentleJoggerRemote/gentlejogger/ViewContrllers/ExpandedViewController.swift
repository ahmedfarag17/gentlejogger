//
//  ExpandedViewController.swift
//  gentlejogger
//
//  Created by hamer farag on 2/25/19.
//  Copyright © 2019 jim. All rights reserved.
//

import UIKit
import Firebase

class ExpandedViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    
    var data: [DatabaseCollection ] = [];
    var count = 0;
    var  monthTitleArray = ["", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

    
    @IBOutlet var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        let value = UIInterfaceOrientation.portrait.rawValue
        UIDevice.current.setValue(value, forKey: "orientation")
        
        var ref: DatabaseReference!
        
        ref = Database.database().reference()
        
        let defaults = UserDefaults.standard
        let user = defaults.string(forKey: "passedUser")
        print("User is ",user)
        let userID = Auth.auth().currentUser?.uid
        ref.child("Users").child(user!).observeSingleEvent(of: .value, with: { (snapshot) in
            // Get user value
            var uid = ""
            for (key,value) in (snapshot.value as? NSDictionary)!{
                uid = value as! String
            }
            ref.child("UserHistory").child(uid).observeSingleEvent(of: .value, with: { (snapshot) in
                // Get user value
                
                if(snapshot.exists()){
                    for (key,value) in (snapshot.value as? NSDictionary)!{
                        self.count+=1;
                        self.data.append(DatabaseCollection.init(date: key as! String, dictionary: value as! Dictionary<String, Any>))
                    }
                    self.data = self.data.sorted(by: { $0.date > $1.date })
                    self.tableView?.reloadData()}
            }) { (error) in
                print(error.localizedDescription)
            }
        }) { (error) in
            print(error.localizedDescription)
        }
        // Do any additional setup after loading the view.
    }
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data[section].sessions.count;
    }
    
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        print("Number of Sections %d", count)
        
        return count;
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 30;
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        var label : UILabel = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 15))
        let date = data[section].date
        
        let month : String = String(date[date.index(date.startIndex, offsetBy: 5)...date.index(date.endIndex, offsetBy: -4)])
        let day = String(date[date.index(date.endIndex, offsetBy: -2)...])
        let year = String(date[date.index(date.startIndex, offsetBy: 0)...date.index(date.startIndex, offsetBy: 3)])
        label.text = "   " + monthTitleArray[Int(month)!] + " " + day + ", " + year;
        label.font = UIFont.boldSystemFont(ofSize: 12)
        //        label.font = UIFont(name: "Optima-Bold", size: 12)
        label.backgroundColor = UIColor(red:0.17, green:0.63, blue:0.93, alpha:1.0)
        label.textAlignment = .left
        label.textColor = UIColor.white
        
        
        return label
    }
    
   
   
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = tableView.dequeueReusableCell(withIdentifier: "expandedCell") as! ExpandedTableViewCell
        
        cell.jogCount.text = data[indexPath.section].sessions[indexPath.item].sessionJog
        cell.walkCount.text = data[indexPath.section].sessions[indexPath.item].sessionWalk
        cell.runCount.text = data[indexPath.section].sessions[indexPath.item].sessionRun
        cell.raceCount.text = data[indexPath.section].sessions[indexPath.item].sessionRace
        
        cell.sessionStepCount.text = data[indexPath.section].sessions[indexPath.item].sessionSteps + " steps"
        
        let date = data[indexPath.section].sessions[indexPath.item].time
        let indexStartOfText = date.index(date.endIndex, offsetBy: -8)
        let indexEndOfText = date.index(date.endIndex, offsetBy: -3)

        cell.sessionDateTime.text = String(date[indexStartOfText..<indexEndOfText])

        return cell
    }
    
    @IBAction func done(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }

}
