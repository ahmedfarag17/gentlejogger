//
//  LoginViewController.m
//  gentlejogger
//
//  Created by hamer farag on 8/1/18.
//  Copyright © 2018 jim. All rights reserved.
//

#import "LoginViewController.h"
@import Firebase;

@interface LoginViewController () <UITextFieldDelegate>
@property (strong, nonatomic) IBOutlet UITextField *email;
@property (strong, nonatomic) IBOutlet UITextField *password;
@property (strong, nonatomic) IBOutlet UILabel *errLabel;

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [_errLabel setHidden:YES];
    [_errLabel setAdjustsFontSizeToFitWidth:YES];
    self.email.delegate = self;
    self.password.delegate = self;
    NSNumber *orientationValue = [NSNumber numberWithInt:UIInterfaceOrientationPortrait];
    [[UIDevice currentDevice] setValue: orientationValue forKey:@"orientation"];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    
    [self.view addGestureRecognizer:tap];
}

- (void)viewWillAppear:(BOOL)animated{
    [[FIRAuth auth] addAuthStateDidChangeListener:^(FIRAuth *_Nonnull auth, FIRUser *_Nullable user) {
        if ([FIRAuth auth].currentUser) {
            // User is signed in.
            NSLog(@"User is signed in from listener");
            [self performSegueWithIdentifier:@"signedIn" sender:self];
            
            NSLog(@"Segued");
        } else {
            // No user is signed in.
            // ...
        }
        
    }];
}

- (BOOL) textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];

    return YES;
}

- (BOOL)shouldAutorotate {
    return NO;
}

-(void)dismissKeyboard
{
    [_email resignFirstResponder];
    [_password resignFirstResponder];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)login:(id)sender {
    [_errLabel setHidden:YES];
    NSString *emailstring = [_email text];
    NSString *passString = [_password text];
    
    if(!emailstring || [emailstring length] == 0 || !passString || [passString length] == 0 || ![self validateEmailWithString:emailstring]){
        [_errLabel setText:@"Please enter an email and password"];
        [_errLabel setHidden:NO];
        return;
    }
    
    [[FIRAuth auth] signInWithEmail:emailstring
                           password:passString
                         completion:^(FIRAuthDataResult * _Nullable authResult,
                                      NSError * _Nullable error) {
                             if (error) {
                                 NSString *err;
                                 if(error == FIRAuthErrorCodeUserNotFound){
                                     err = @"User not found.";
                                 }else if(error == FIRAuthErrorCodeNetworkError){
                                     err = @"No Internet Connection";
                                 }else if(error == FIRAuthErrorCodeWrongPassword){
                                     err = @"Invalid Password";
                                     NSLog(error.localizedDescription);
                                 }else if(error == FIRAuthErrorCodeNetworkError){
                                     err = @"Network Error. Please connect to the internet";
                                 }else{
                                     err = error.localizedDescription;
                                 }
                                 [_errLabel setText:err];
                                 [_errLabel setHidden:NO];
                                 return;
                             }
                             NSLog(@"User logged in");
                             //              [self.navigationController popViewControllerAnimated:YES];
                         }];
}

- (BOOL)validateEmailWithString:(NSString*)email
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
