//
//  ReportingViewController.swift
//  gentlejogger
//
//  Created by hamer farag on 8/4/18.
//  Copyright © 2018 jim. All rights reserved.
//

import UIKit
import Charts
import Firebase

class ReportingViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    

    @IBOutlet var backgroundView: UIView!
    @IBOutlet var reportTableView: UITableView!
    @IBOutlet weak var lineChartView: CombinedChartView!
    var m_showTblData: NSMutableArray = [];
//    @IBOutlet var moreInfo: UIBarButtonItem!
    var firebasedata: [DatabaseCollection ] = [];
    var count = 0;
    @IBOutlet var noDataView: UIView!
    
    var selectedCell : IndexPath? = nil;
    var  monthTitleArray = ["", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

    override func viewDidLoad() {
        super.viewDidLoad()
//        let gradient = CAGradientLayer()
//        
//        gradient.frame = view.bounds
//        gradient.colors = [UIColor(red:0.17, green:0.63, blue:0.93, alpha:1.0).cgColor, UIColor.white.cgColor]
//        
//        backgroundView.layer.insertSublayer(gradient, at: 0)
        
        var ref: DatabaseReference!
        
        ref = Database.database().reference()
        
        let userID = Auth.auth().currentUser?.uid
        ref.child("UserHistory").child(userID!).observeSingleEvent(of: .value, with: { (snapshot) in
            // Get user value
            
            for (key,value) in (snapshot.value as? NSDictionary)!{
                self.count+=1;
                self.firebasedata.append(DatabaseCollection.init(date: key as! String, dictionary: value as! Dictionary<String, Any>))
            }
            self.firebasedata = self.firebasedata.sorted(by: { $0.date > $1.date })
            self.setChartValues();
            self.reportTableView.reloadData()
        }) { (error) in
            print(error.localizedDescription)
        }
        
       
//        view .backgroundColor = UIColor(red:0.16, green:0.18, blue:0.20, alpha:1.0);
//        let value = UIInterfaceOrientation.landscapeRight.rawValue
//        UIDevice.current.setValue(value, forKey: "orientation")
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1;
    }
    
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        print("Number of Sections")
        print(firebasedata.count)
        return firebasedata.count;
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 21;
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        var label : UILabel = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 15))
        let date = firebasedata[section].date
        
        let month : String = String(date[date.index(date.startIndex, offsetBy: 5)...date.index(date.endIndex, offsetBy: -4)])
        let day = String(date[date.index(date.endIndex, offsetBy: -2)...])
        let year = String(date[date.index(date.startIndex, offsetBy: 0)...date.index(date.startIndex, offsetBy: 3)])
        label.text = "   " + monthTitleArray[Int(month)!] + " " + day + ", " + year;
        label.font = UIFont.boldSystemFont(ofSize: 12)
//        label.font = UIFont(name: "Optima-Bold", size: 12)
        label.backgroundColor = UIColor(red:0.17, green:0.63, blue:0.93, alpha:1.0)
        label.textAlignment = .left
        label.textColor = UIColor.white
        return label
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        switch selectedCell {
        case nil:
            selectedCell = indexPath
        default:
            if selectedCell! == indexPath {
                selectedCell = nil
            } else {
                selectedCell = indexPath
            }
        }
        tableView.reloadRows(at: [indexPath], with: UITableViewRowAnimation.automatic)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if(selectedCell == indexPath){
            return CGFloat(170);
        }else{
            return CGFloat(50);
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       
        
        if(selectedCell == indexPath){
           let cell = tableView.dequeueReusableCell(withIdentifier: "expandedCell") as! ExpandedReportTableViewCell
            
            let steps = firebasedata[indexPath.section].secs + " steps";
            
            var mutatedString = NSMutableAttributedString.init(string: steps)
           
            
            // set the custom font and color for the 0,1 range in string
            mutatedString.setAttributes([NSAttributedStringKey.font: UIFont.systemFont(ofSize: 10),
                                       NSAttributedStringKey.foregroundColor: UIColor.gray],
                                      range: NSRange(location: steps.count-6, length: 6))
            cell.stepsLabel.attributedText = mutatedString;
            
            let timeInNum = firebasedata[indexPath.section].time;
            let minutes = (Int(firebasedata[indexPath.section].time)!/60);
            let seconds = (Int(firebasedata[indexPath.section].time)!%60);
            let time = String(minutes) + ":" + String(seconds) + " mins"
            mutatedString = NSMutableAttributedString.init(string: time)
            
            
            // set the custom font and color for the 0,1 range in string
            mutatedString.setAttributes([NSAttributedStringKey.font: UIFont.systemFont(ofSize: 10),
                                       NSAttributedStringKey.foregroundColor: UIColor.gray],
                                      range: NSRange(location: time.count-5, length: 5))

            cell.timeLabel.attributedText = mutatedString ;
            
            
            var pace = firebasedata[indexPath.section].pace + " steps/min";
            if(pace == "nan steps/min"){
                pace = "0 steps/min"
            }
            mutatedString = NSMutableAttributedString.init(string: pace)
            
            
            // set the custom font and color for the 0,1 range in string
            mutatedString.setAttributes([NSAttributedStringKey.font: UIFont.systemFont(ofSize: 10),
                                         NSAttributedStringKey.foregroundColor: UIColor.gray],
                                        range: NSRange(location: pace.count-10, length: 10))
            cell.paceLabel.attributedText = mutatedString ;
            
            let userDefault = UserDefaults.standard
            let device_steps = userDefault.object(forKey: "step") as! String
//            print("Current Steps = %d", Int(steps)!)
//            print("Device Steps = %d", Int(device_steps)!);
            
            var percent = Float(firebasedata[indexPath.section].secs)!/Float(device_steps)!;
            if(percent>1){
                percent = 1;
            }
            cell.percent = percent
            cell.create()
            return cell;
        }else{
           let cell = tableView.dequeueReusableCell(withIdentifier: "reportCell") as! ReportTableViewCell
            
//            let steps = firebasedata[indexPath.section].secs;
//            cell.stepsLabel.text = steps + " steps";
            let steps = firebasedata[indexPath.section].secs + " steps";
            
            let stepsString = NSMutableAttributedString.init(string: steps)
            
            
            // set the custom font and color for the 0,1 range in string
            
            stepsString.setAttributes([NSAttributedStringKey.font: UIFont.systemFont(ofSize: 12),
                                       NSAttributedStringKey.foregroundColor: UIColor.gray],
                                      range: NSRange(location: steps.count-6, length: 6))
            cell.stepsLabel.attributedText = stepsString;
            print("after Setting")

            let userDefault = UserDefaults.standard
            let device_steps = userDefault.object(forKey: "step") as! String
//            print("Current Steps = %d", Int(steps)!)
//            print("Device Steps = %d", Int(device_steps)!);
            
            var percent = Float(firebasedata[indexPath.section].secs)!/Float(device_steps)!;
            if(percent>1){
                percent = 1;
            }
            cell.percent = percent
            cell.create()
            return cell;
        }
        
        

        
       
    }
    
    
    
    func setChartValues(_ count: Int = 20, type: Int = 0){
        
        if type == 0 {
            m_showTblData = SqlManager.init().getResultArrayForDaily()
        } else if type == 1 {
            m_showTblData = SqlManager.init().getWeeklyData()
        } else if type == 2 {
            m_showTblData = SqlManager.init().getMonthlyData()
        }
        if(m_showTblData.count == 0){
            noDataView.isHidden = false;
//            moreInfo.isEnabled = false;
            return;
        }else{
            noDataView.isHidden = true;
//            moreInfo.isEnabled = true;

        }
        monthTitleArray = ["", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
        var xValues: [String] = [];
        for i in (0...firebasedata.count-1).reversed(){
//            let x: DataBaseItem = m_showTblData.object(at: i) as! DataBaseItem;
            print(" Count = %d and Firebase = %d", i, firebasedata.count );
            let date = firebasedata[i].date
            let month = String(date[date.index(date.startIndex, offsetBy: 5)...date.index(date.endIndex, offsetBy: -4)])
            let day = String(date[date.index(date.endIndex, offsetBy: -2)...])
            print(date)
            print(month)
            print(day)
            var title = "\(monthTitleArray[Int(month)!]) \(day)"
//            if type == 1 {
//                let timeString = CommonAPI.getWeekStartMonthDate(from: x.yearNumber, weekNumOfYear: x.weekNum)
//                title = timeString!
//            }
//            if type == 2 {
//                title = "\(monthTitleArray[Int(x.monthNumber)])"
//            }

            xValues.append(title);
//            print(x.date);
//            print(x.steps);
//            print(x.secs);
//            print(x.pace);
        }
        print("Done")

        var values = ((0...firebasedata.count-1).reversed()).map {
            (i) -> BarChartDataEntry in
                let x = firebasedata[i].secs;
            
            return BarChartDataEntry(x: Double(i), y: Double(x)!);
        }
        
//        var values2 = ((0...firebasedata.count-1).reversed()).map {
//            (i) -> ChartDataEntry in
//            let x = firebasedata[i].time;
//
//            return ChartDataEntry(x: Double(i), y: Double(x)!);
//        }
        
        
        let set1 = BarChartDataSet(values: values, label: "Steps");
        set1.axisDependency = .left
        
        set1.colors = [UIColor(red:0.17, green:0.63, blue:0.93, alpha:1.0)];
//        let set2 = LineChartDataSet(values: values2, label: "Time");
//        set2.axisDependency = Charts.YAxis.AxisDependency.right
//        set2.colors = [UIColor(red:0.82, green:0.11, blue:0.11, alpha:1.0)]
//        set2.circleColors = [UIColor(red:0.82, green:0.11, blue:0.11, alpha:1.0)]

        let data: CombinedChartData = CombinedChartData(dataSets: [set1])
        data.barData = BarChartData(dataSet: set1)
//        data.lineData = LineChartData(dataSet: set2)
        
        lineChartView.data = data
        print(xValues);
        lineChartView.drawBordersEnabled = false
        lineChartView.minOffset = 0
        lineChartView.xAxis.axisMinimum = -0.5;
        lineChartView.xAxis.axisMaximum = Double(values.count) - 0.5;
        lineChartView.xAxis.valueFormatter = IndexAxisValueFormatter(values: xValues);
//        lineChartView.xAxis.granularityEnabled = true
//        lineChartView.xAxis.granularity = 1.0
        lineChartView.xAxis.labelPosition = XAxis.LabelPosition.bottom
        lineChartView.animate(xAxisDuration: 0.5, yAxisDuration: 0.5, easingOption: .easeInBounce)
//        lineChartView.noDataText = "You have not worked out yet!"
        lineChartView.xAxis.drawGridLinesEnabled = false;
        lineChartView.rightAxis.enabled = false;
        lineChartView.chartDescription?.text = ""
//        lineChartView.leftAxis.enabled = false
//         lineChartView.leftAxis.drawGridLinesEnabled = false;
        lineChartView.rightAxis.drawGridLinesEnabled = false;
//        lineChartView.leftAxis.axisLineColor = UIColor(red:0.05, green:0.40, blue:0.63, alpha:1.0)
//        lineChartView.rightAxis.axisLineColor = UIColor(red:0.82, green:0.11, blue:0.11, alpha:1.0)
        
//        lineChartView.leftAxis.axisLineWidth = 2
//        lineChartView.rightAxis.axisLineWidth = 2;
//        lineChartView.xAxis.axisLineWidth = 2
//        lineChartView.chartDescription?.text = ""
////        lineChartView.backgroundColor = UIColor(red:0.16, green:0.18, blue:0.20, alpha:1.0);
//        lineChartView.noDataTextColor = UIColor(red:1.00, green:1.00, blue:1.00, alpha:1.0);
    
        
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        if UIDevice.current.orientation.isLandscape {
            print("Landscape")
            reportTableView.isHidden = true
        } else {
            print("Portrait")
            reportTableView.isHidden = false
        }
    }
    
  
    


}
