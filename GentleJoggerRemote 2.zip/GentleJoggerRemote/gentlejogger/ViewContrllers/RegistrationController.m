//
//  ViewController.m
//  gentlejogger
//
//  Created by mojado on 4/13/17.
//  Copyright © 2017 Sackner Wellness All rights reserved.
//

#import "RegistrationController.h"
#import "DeviceMemory.h"
#import <MessageUI/MessageUI.h>
#import "LoginViewController.h"
@import Firebase;

#define UIColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

@interface RegistrationController () <UITextFieldDelegate,MFMailComposeViewControllerDelegate>{
    
    IBOutlet UIView *mViewContainer;
    IBOutlet UIButton *mJoinBtn;
    IBOutlet UIView *mBottomBiew;
    FIRUser *user;
}

@property (strong, nonatomic) IBOutlet UITextField *edt_firstName;
@property (strong, nonatomic) IBOutlet UITextField *edt_lastName;
@property (strong, nonatomic) IBOutlet UITextField *edt_organization;
@property (strong, nonatomic) IBOutlet UITextField *edt_address1;
@property (strong, nonatomic) IBOutlet UITextField *edt_address2;
@property (strong, nonatomic) IBOutlet UITextField *edt_city;
@property (strong, nonatomic) IBOutlet UITextField *edt_state;
@property (strong, nonatomic) IBOutlet UITextField *edt_zip;
@property (strong, nonatomic) IBOutlet UITextField *edt_email;
@end

@implementation RegistrationController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initNavigationBar];
    
    mViewContainer.layer.borderColor = [UIColorFromRGB(0x979797) CGColor];
    mViewContainer.layer.borderWidth = 2;
    mViewContainer.backgroundColor = UIColorFromRGB(0x006fba);
    
    mJoinBtn.layer.borderWidth = 1;
    mJoinBtn.layer.borderColor = [UIColorFromRGB(0x007AFF) CGColor];
    mJoinBtn.layer.cornerRadius = 5;
    
    mBottomBiew.layer.borderColor = [UIColorFromRGB(0x979797) CGColor];
    mBottomBiew.layer.borderWidth = 1;
    
    NSUserDefaults * userDefault = [NSUserDefaults standardUserDefaults];
    BOOL isRegisted = [userDefault boolForKey:USER_KEY_IS_REGISTED];
    if(isRegisted){
        [self.edt_firstName setText:[userDefault objectForKey:USER_KEY_FIRST_NAME]];
        [self.edt_lastName setText:[userDefault objectForKey:USER_KEY_LAST_NAME]];
        [self.edt_organization setText:[userDefault objectForKey:USER_KEY_ORG_NAME]];
        [self.edt_address1 setText:[userDefault objectForKey:USER_KEY_ADD1_NAME]];
        [self.edt_address2 setText:[userDefault objectForKey:USER_KEY_ADD2_NAME]];
        [self.edt_city setText:[userDefault objectForKey:USER_KEY_CITY_NAME]];
        [self.edt_state setText:[userDefault objectForKey:USER_KEY_STATE_NAME]];
        [self.edt_zip setText:[userDefault objectForKey:USER_KEY_ZIP_NAME]];
        [self.edt_email setText:[userDefault objectForKey:USER_KEY_EMAIL_NAME]];
    }
    self.edt_firstName.delegate = self;
    self.edt_lastName.delegate = self;
    self.edt_organization.delegate = self;
    self.edt_address1.delegate = self;
    self.edt_address2.delegate = self;
    self.edt_city.delegate = self;
    self.edt_state.delegate = self;
    self.edt_zip.delegate = self;
    self.edt_email.delegate = self;
    
    user = [FIRAuth auth].currentUser;
    if (user) {
        // The user's ID, unique to the Firebase project.
        // Do NOT use this value to authenticate with your backend server,
        // if you have one. Use getTokenWithCompletion:completion: instead.
        NSLog(@"Name  = %@", user.displayName);
        [self.edt_firstName setText:[user.displayName substringToIndex:[user.displayName rangeOfString:@" "].location]];
        [self.edt_lastName setText:[user.displayName substringFromIndex:[user.displayName rangeOfString:@" "].location+1]];
        [self.edt_email setText:user.email];
        // ...
    }
    
}

- (void)initNavigationBar {
    [self.navigationController.navigationBar setHidden:NO];
    
    [self setTitle:@"Registration"];
    
//    UIBarButtonItem * rescanButton = [[UIBarButtonItem alloc]initWithTitle:@"Rescan" style:UIBarButtonItemStyleDone target:self action:@selector(clickRescan)];
//    self.navigationItem.rightBarButtonItem = rescanButton;
}

-(void)clickRescan{
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)onJoin:(id)sender {
//    if(self.edt_firstName.text.length > 0 && self.edt_lastName.text.length > 0 && self.edt_email.text.length > 0){
        MFMailComposeViewController *picker = [[MFMailComposeViewController alloc] init];
        if(picker){
            [picker setEditing:YES];
            picker.mailComposeDelegate = self;
            
            [picker setSubject:@"Please add me to your email list"];
            
            // Set up recipients
            NSArray *toRecipients = [NSArray arrayWithObject:@"support@sacknerwellness.com"];
            
            [picker setToRecipients:toRecipients];
            
            ///Registration Information:\n\n<field name>:<field value>\n" repeating field value:name for all registration form values
            
            NSString * emailbody = @"Registration Information:\n\n";
            emailbody = [emailbody stringByAppendingFormat:@"First Name: %@\n", self.edt_firstName.text];
            emailbody = [emailbody stringByAppendingFormat:@"Last Name: %@\n", self.edt_lastName.text];
            emailbody = [emailbody stringByAppendingFormat:@"Organization: %@ \n", self.edt_organization.text];
            emailbody = [emailbody stringByAppendingFormat:@"Address1: %@ %@\n", self.edt_address1.text, self.edt_address2.text];
            emailbody = [emailbody stringByAppendingFormat:@"Address2: %@ %@\n", self.edt_city.text, self.edt_state.text];
            emailbody = [emailbody stringByAppendingFormat:@"Zip Code: %@ \n", self.edt_zip.text];
            emailbody = [emailbody stringByAppendingFormat:@"Email: %@ \n", self.edt_email.text];
            
            if(self.edt_email.text.length > 0){
                emailbody = [emailbody stringByAppendingFormat:@"\n\nPlease add my email address above to your list for occasional email announcements about the Gentle Jogger and Sackner Wellness, Inc. \nI understand that you will not share my information with any other party."];
            }
            
            [picker setMessageBody:emailbody isHTML:NO];
            
            [self presentViewController:picker animated:YES completion:NULL];
        }
        
        NSUserDefaults * userDefault = [NSUserDefaults standardUserDefaults];
        [userDefault setBool:YES forKey:USER_KEY_IS_REGISTED];
        [userDefault setObject:self.edt_firstName.text forKey:USER_KEY_FIRST_NAME];
        [userDefault setObject:self.edt_lastName.text forKey:USER_KEY_LAST_NAME];
        [userDefault setObject:self.edt_organization.text forKey:USER_KEY_ORG_NAME];
        [userDefault setObject:self.edt_address1.text forKey:USER_KEY_ADD1_NAME];
        [userDefault setObject:self.edt_address2.text forKey:USER_KEY_ADD2_NAME];
        [userDefault setObject:self.edt_city.text forKey:USER_KEY_CITY_NAME];
        [userDefault setObject:self.edt_state.text forKey:USER_KEY_STATE_NAME];
        [userDefault setObject:self.edt_zip.text forKey:USER_KEY_ZIP_NAME];
        [userDefault setObject:self.edt_email.text forKey:USER_KEY_EMAIL_NAME];
        [userDefault synchronize];
        
//    }else{
//        [[[UIAlertView alloc] initWithTitle:nil message:@"Please insert user info." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil] show];
//    }
}
- (void)mailComposeController:(MFMailComposeViewController*)controller
          didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{
    [self dismissViewControllerAnimated:YES completion:NULL];
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    CGRect currentRect = [self.view convertRect:textField.frame fromView:textField.superview];
    int height = self.view.frame.size.height - currentRect.origin.y - currentRect.size.height;
    if(height < 300){
        height = 300 - height;
        [UIView animateWithDuration:0.2 animations:^(void){
            CGRect selfRect = self.view.frame;
            selfRect.origin.y = -height;
            [self.view setFrame:selfRect];
        } completion:^(BOOL finished){
        }];
    }
    return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    [UIView animateWithDuration:0.2 animations:^(void){
        CGRect selfRect = self.view.frame;
        selfRect.origin.y = 0;
        [self.view setFrame:selfRect];
    } completion:^(BOOL finished){
    }];
    return YES;
}
- (IBAction)signOut:(id)sender {
    NSError *signOutError;
    BOOL status = [[FIRAuth auth] signOut:&signOutError];
    if (!status) {
        NSLog(@"Error signing out: %@", signOutError);
        return;
    }
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:
                                @"Main" bundle:[NSBundle mainBundle]];
    UIViewController *myController = [storyboard instantiateViewControllerWithIdentifier:@"loginController"];
    [self presentViewController:myController animated:YES completion:nil];
    
}

- (BOOL)validateEmailWithString:(NSString*)email
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}

- (IBAction)saveInfo:(id)sender {
    if(self.edt_email.text && [self.edt_email.text caseInsensitiveCompare:user.email] != NSOrderedSame){
        if(![self validateEmailWithString:self.edt_email.text]){
            NSLog(@"Invalid Email");
        }else{
            [[FIRAuth auth].currentUser updateEmail:self.edt_email.text completion:^(NSError *_Nullable error) {
                if(error){
                    NSLog(@"Error: %@", error.localizedDescription);
                }else{
                    NSLog(@"Successfully updated email");
                }
            }];
        }
    }
    FIRUserProfileChangeRequest *changeRequest = [[FIRAuth auth].currentUser profileChangeRequest];
    NSLog(@"FIrst = %@ and Last = %@",[self.edt_firstName text], [self.edt_lastName text]);
    NSString *name = [NSString stringWithFormat:@"%@ %@", [self.edt_firstName text], [self.edt_lastName text]];
    NSLog(@"NAme Combined = %@", name);
    changeRequest.displayName = name;
    [changeRequest commitChangesWithCompletion:^(NSError *_Nullable error) {
        if(error){
            NSLog(@"Error: %@", error.localizedDescription);
        }else{
            NSLog(@"NAme = %@", name);
            NSLog(@"Successfully updated name");
            [self.navigationController popViewControllerAnimated:YES];
        }
    }];
    
    
}

- (BOOL)shouldAutorotate {
    return NO;
}
@end
