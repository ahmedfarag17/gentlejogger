//
//  PopUpViewController.swift
//  gentlejogger
//
//  Created by hamer farag on 1/23/19.
//  Copyright © 2019 jim. All rights reserved.
//

import UIKit
import Firebase

class PopUpViewController: UIViewController {
    @IBOutlet var email: UITextField!
    var delegate : SomeProtocol?

    @IBOutlet var errorLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        email.text = "";

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func close(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func save(_ sender: Any) {
        if(email.text != ""){
            let defaults = UserDefaults.standard
            var data = defaults.array(forKey: "sharedUsers") as! [String]
            if (!data.isEmpty) {
                if data.first(where: { $0 as? String == email.text }) != nil {
                    errorLabel.text = "Already one of your shared users"
                    print("Already one of your shared users")
                    return
                }else{
                }
            }
            var ref: DatabaseReference!
            
            ref = Database.database().reference()
            let userID : String = Auth.auth().currentUser!.uid
            let emailString = email.text?.replacingOccurrences(of: ".", with: ",");

            ref.child("Users").child(emailString!).observeSingleEvent(of: .value, with: { (snapshot) in
                // Get user value
                print("Snapshot = %@",snapshot.exists())
                if(snapshot.exists()){
                    ref.child("SharedUsers").child(userID).child(emailString!).setValue(false) { (error, ref) in
                        if error == nil {
                            data.append(self.email.text!)
                            data = data.sorted()
                            defaults.set(data, forKey: "sharedUsers")
                            print(data)
                            self.delegate?.refresh()
                            self.dismiss(animated: true)
                        } else {
                            print(error?.localizedDescription ?? "Failed to update value")
                        }
                    }
                }else{
                    self.errorLabel.text = "Not a valid user email"

                }
                
                // ...
            }) { (error) in
                print(error.localizedDescription)
            }
            
            
        }
    }
}
