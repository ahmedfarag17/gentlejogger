//
//  ViewController.m
//  gentlejogger
//
//  Created by mojado on 4/13/17.
//  Copyright © 2017 Sackner Wellness All rights reserved.
//

#import "MainController.h"

@interface MainController ()

@end

@implementation MainController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    for(UITabBarItem * setupItem in [self.tabBar items]) {
        [setupItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                           [UIFont boldSystemFontOfSize:12], NSFontAttributeName, nil]
                                 forState:UIControlStateNormal];
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotate {
    return NO;
}
@end
