//
//  ViewController.m
//  gentlejogger
//
//  Created by mojado on 4/13/17.
//  Copyright © 2017 Sackner Wellness All rights reserved.
//

#import "SelectDeviceController.h"
#import "DeviceMemory.h"
#import "AppDelegate.h"
#import "deviceitem.h"

@interface SelectDeviceController ()<UITableViewDelegate, UITableViewDataSource, BluetoothDeviceResultDelegate> {
    
    IBOutlet UITableView *mDeviceTableView;
    NSMutableArray * device_array;
    NSDictionary * selected_device;
    
    NSString * selectedDeviceName;
    NSString * selectedDeviceUUID;
}

@end

@implementation SelectDeviceController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initNavigationBar];
    
    [[DeviceMemory createInstance] setBluetoothDeviceResultReceiver:self];
    
    LogicViewController * m_mainview = ((DeviceMemory*)[DeviceMemory createInstance])._mainViewController;
    device_array = [m_mainview getDeviceList];
    
    if(device_array && device_array.count > 0){
        
        [device_array sortUsingComparator:^NSComparisonResult(id  obj1, id obj2){
            NSDictionary * Obj1 = (NSDictionary*)obj1;
            NSDictionary * Obj2 = (NSDictionary*)obj2;
            
            float rssi1 = [[Obj1 objectForKey:@"RSSI"] floatValue];
            float rssi2 = [[Obj2 objectForKey:@"RSSI"] floatValue];
            if(rssi1 < rssi2) return NSOrderedDescending;
            else if(rssi1 > rssi2) return NSOrderedAscending;
            return NSOrderedSame;
        }];
        
        [mDeviceTableView reloadData];
        
        NSString * device_name = [[DeviceMemory createInstance] deveice_name];
        NSString * device_uuid = [[DeviceMemory createInstance] device_uuidStr];
        if(device_name && device_uuid){
            selectedDeviceName = device_name;
            selectedDeviceUUID = device_uuid;
        }
        
    }else{
        [self clickRescan];
    }
    
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [[DeviceMemory createInstance] setBluetoothDeviceResultReceiver:self];
    
    LogicViewController * m_mainview = ((DeviceMemory*)[DeviceMemory createInstance])._mainViewController;
    device_array = [m_mainview getDeviceList];
    
    if(device_array && device_array.count > 0){
        
        [device_array sortUsingComparator:^NSComparisonResult(id  obj1, id obj2){
            NSDictionary * Obj1 = (NSDictionary*)obj1;
            NSDictionary * Obj2 = (NSDictionary*)obj2;
            
            float rssi1 = [[Obj1 objectForKey:@"RSSI"] floatValue];
            float rssi2 = [[Obj2 objectForKey:@"RSSI"] floatValue];
            if(rssi1 < rssi2) return NSOrderedDescending;
            else if(rssi1 > rssi2) return NSOrderedAscending;
            return NSOrderedSame;
        }];
        
        
    }
    [mDeviceTableView reloadData];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    deviceitem *cell = (deviceitem*)[tableView dequeueReusableCellWithIdentifier:@"deviceitem"];
    if(cell){
        NSDictionary * device  = [device_array objectAtIndex:indexPath.row];
        NSString * deviceUUID = [device objectForKey:@"peripheral-identifier-UUIDString"];
        NSString * deviceName = [device objectForKey:@"peripheral-name"];
        NSNumber * rssi = [device objectForKey:@"RSSI"];
        if(deviceName.length > 2 && [[deviceName substringToIndex:2] isEqualToString:@"GJ"]){
            cell.lbl_name.text = @"Gentle Jogger";
            NSString * new_deviceName = [deviceName substringFromIndex:2];
            cell.lbl_nickName.text = new_deviceName;
        }else{
            cell.lbl_name.text = deviceName;
            cell.lbl_nickName.text = @"";
        }
    }
    return cell;
}
- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary * device  = [device_array objectAtIndex:indexPath.row];
    NSString * deviceUUID = [device objectForKey:@"peripheral-identifier-UUIDString"];
    NSString * deviceName = [device objectForKey:@"peripheral-name"];
    NSNumber * rssi = [device objectForKey:@"RSSI"];
    selectedDeviceUUID = deviceUUID;
    selectedDeviceName = deviceName;
    
    NSLog(@"---------------------\nSelect %@\n----------------",selectedDeviceName);
    
    NSString * seleced_device_name = [[DeviceMemory createInstance] deveice_name];
    NSString * seleced_device_uuid = [[DeviceMemory createInstance] device_uuidStr];
    
    if(![[DeviceMemory createInstance] isConnected]){
        [self sendCMDConnect:deviceName :deviceUUID];
    }else{
        if([deviceUUID isEqualToString:seleced_device_uuid] && [deviceName isEqualToString:seleced_device_name]){
            [self.navigationController popViewControllerAnimated:YES];
        }else{
            [[DeviceMemory createInstance] setDevice_uuidStr:deviceUUID];
            [[DeviceMemory createInstance] setDeveice_name:deviceName];
            [[DeviceMemory createInstance] setLockForTab:YES];
            ///disconnect from device
            [self sendCMDDisConnect:seleced_device_name :seleced_device_uuid];
            
            [[DeviceMemory createInstance] setIsConnected:NO];
            /// connect
            [self sendCMDConnect:deviceName :deviceUUID];
        }
    }
    
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [device_array count];
}

- (void)initNavigationBar {
    [self.navigationController.navigationBar setHidden:NO];
    
    [self setTitle:@"Select Device"];
    
    UIBarButtonItem * rescanButton = [[UIBarButtonItem alloc]initWithTitle:@"Rescan" style:UIBarButtonItemStyleDone target:self action:@selector(clickRescan)];
    self.navigationItem.rightBarButtonItem = rescanButton;
}

-(void)clickRescan{
    
    NSString * seleced_device_name = [[DeviceMemory createInstance] deveice_name];
    NSString * seleced_device_uuid = [[DeviceMemory createInstance] device_uuidStr];
    [[DeviceMemory createInstance] setBluetoothDeviceResultReceiver:self];
    if(seleced_device_name && seleced_device_uuid){
        ///disconnect from device
        [self sendCMDDisConnect:seleced_device_name :seleced_device_uuid];
    }
    
    [[DeviceMemory createInstance] setIsConnected:NO];
    
    [self sendCMDScan];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void) onStartScan
{
    LogicViewController * m_mainview = ((DeviceMemory*)[DeviceMemory createInstance])._mainViewController;
    [m_mainview removeDeviceList];
    [self sendCMDScan];
}

- (void) sendCMDScan
{
    LogicViewController * m_mainview = ((DeviceMemory*)[DeviceMemory createInstance])._mainViewController;
    [m_mainview removeDeviceList];
    
    BLECMD * scanCommand = [BLECMD new];
    scanCommand.cmdStr = CMDSTR_SCANDEVICE;
    scanCommand.cmd_id = 0;
    scanCommand.cmd_waitTime = 5;
    [m_mainview sendCMDObject:scanCommand];
    
    if(!device_array || device_array.count == 0){
        AppDelegate * appdelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
        [appdelegate showLoader];
    }
}
- (void) sendCMDConnect:(NSString*)deviceName :(NSString*)deviceUUID
{
    LogicViewController * m_mainview = ((DeviceMemory*)[DeviceMemory createInstance])._mainViewController;
    BLECMD * scanCommand = [BLECMD new];
    scanCommand.cmdStr = CMDSTR_CONNECTDEVICE;
    scanCommand.cmd_id = 10;
    scanCommand.cmd_waitTime = 10;
    NSMutableDictionary * dict = [NSMutableDictionary new];
    [dict setObject:deviceUUID forKey:@"peripheral-identifier-UUIDString"];
    [dict setObject:deviceName forKey:@"peripheral-identifier-Name"];
    scanCommand.cmdData = dict;
    [m_mainview sendCMDObject:scanCommand];
    
    AppDelegate * appdelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [appdelegate showLoader];
}

- (void) sendCMDDisConnect:(NSString*)deviceName :(NSString*)deviceUUID
{
    LogicViewController * m_mainview = ((DeviceMemory*)[DeviceMemory createInstance])._mainViewController;
    BLECMD * scanCommand = [BLECMD new];
    scanCommand.cmdStr = CMDSTR_DISCONNECTDEVICE;
    scanCommand.cmd_id = 10;
    scanCommand.cmd_waitTime = 10;
    NSMutableDictionary * dict = [NSMutableDictionary new];
    [dict setObject:deviceUUID forKey:@"peripheral-identifier-UUIDString"];
    [dict setObject:deviceName forKey:@"peripheral-identifier-Name"];
    scanCommand.cmdData = dict;
    [m_mainview sendCMDObject:scanCommand];
    
    AppDelegate * appdelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [appdelegate showLoader];
}
- (void) sendCMDNotifySet
{
    AppDelegate * appdelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [appdelegate hideLoader];
    if(selectedDeviceUUID && selectedDeviceName){
        LogicViewController * m_mainview = ((DeviceMemory*)[DeviceMemory createInstance])._mainViewController;
        m_mainview.ble_delegate = self;
        BLECMD * scanCommand = [BLECMD new];
        scanCommand.cmdStr = CMDSTR_NOTIFY;
        scanCommand.cmd_id = 100;
        scanCommand.cmd_waitTime = 40;
        NSMutableDictionary * dict = [NSMutableDictionary new];
        [dict setObject:selectedDeviceUUID forKey:@"peripheral-identifier-UUIDString"];
        [dict setObject:selectedDeviceName forKey:@"peripheral-identifier-Name"];
        scanCommand.cmdData = dict;
        [m_mainview sendCMDObject:scanCommand];
        [[DeviceMemory createInstance] setLockForTab:YES];
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)BluetoothDeviceResult:(BLERESP*)response
{
    if([response.function isEqualToString:@"didDiscoverPeripheral"]){
        AppDelegate * appdelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
        [appdelegate hideLoader];
        
        LogicViewController * m_mainview = ((DeviceMemory*)[DeviceMemory createInstance])._mainViewController;
        device_array = [m_mainview getDeviceList];
        
        [device_array sortUsingComparator:^NSComparisonResult(id  obj1, id obj2){
            NSDictionary * Obj1 = (NSDictionary*)obj1;
            NSDictionary * Obj2 = (NSDictionary*)obj2;
            
            float rssi1 = [[Obj1 objectForKey:@"RSSI"] floatValue];
            float rssi2 = [[Obj2 objectForKey:@"RSSI"] floatValue];
            if(rssi1 < rssi2) return NSOrderedDescending;
            else if(rssi1 > rssi2) return NSOrderedAscending;
            return NSOrderedSame;
        }];
        
        [mDeviceTableView reloadData];
    }else if([response.function isEqualToString:@"didConnectPeripheral"]){
        
        if(response.messageType == 0)/// return connect error
        {
            AppDelegate * appdelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
            [appdelegate hideLoader];
            [[DeviceMemory createInstance] setIsConnected:NO];
            [[[UIAlertView alloc] initWithTitle:nil message:@"Device connect fail." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil] show];
            [self sendCMDScan];
        }else{
            
            NSUserDefaults * defaultVal = [NSUserDefaults standardUserDefaults];
            [defaultVal setObject:selectedDeviceUUID forKey:SYS_KEY_ALREADYCONNECTED_UUID];
            [defaultVal setObject:selectedDeviceName forKey:SYS_KEY_ALREADYCONNECTED_NAME];
            [defaultVal synchronize];
            
            [[DeviceMemory createInstance] setDevice_uuidStr:selectedDeviceUUID];
            [[DeviceMemory createInstance] setDeveice_name:selectedDeviceName];
            [[DeviceMemory createInstance] setIsConnected:YES];
            
            NSLog(@"---------------------\nSelect connect%@\n----------------",selectedDeviceName);
            
            [self performSelector:@selector(sendCMDNotifySet) withObject:nil afterDelay:5];
        }
    }else if([response.function isEqualToString:@"endCMD"]){
        AppDelegate * appdelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
        [appdelegate hideLoader];
        LogicViewController * m_mainview = ((DeviceMemory*)[DeviceMemory createInstance])._mainViewController;
        device_array = [m_mainview getDeviceList];
        [device_array sortUsingComparator:^NSComparisonResult(id  obj1, id obj2){
            NSDictionary * Obj1 = (NSDictionary*)obj1;
            NSDictionary * Obj2 = (NSDictionary*)obj2;
            
            float rssi1 = [[Obj1 objectForKey:@"RSSI"] floatValue];
            float rssi2 = [[Obj2 objectForKey:@"RSSI"] floatValue];
            if(rssi1 < rssi2) return NSOrderedDescending;
            else if(rssi1 > rssi2) return NSOrderedAscending;
            return NSOrderedSame;
        }];
        
        [mDeviceTableView reloadData];
    }else if([response.function isEqualToString:@"didDisconnectPeripheral"]){
        //        [[[UIAlertView alloc] initWithTitle:nil message:@"Device is disconnected" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil] show];
    }
}

- (BOOL)shouldAutorotate {
    return NO;
}
@end
