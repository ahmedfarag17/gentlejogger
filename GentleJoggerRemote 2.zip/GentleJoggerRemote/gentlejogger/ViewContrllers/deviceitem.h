//
//  deviceitem.h
//  gentlejogger
//
//  Created by mojado on 4/19/17.
//  Copyright © 2017 Sackner Wellness All rights reserved.
//

#import <UIKit/UIKit.h>

@interface deviceitem : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *lbl_name;
@property (strong, nonatomic) IBOutlet UILabel *lbl_nickName;

@end
