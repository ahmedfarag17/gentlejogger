//
//  ReportCollectionViewController.swift
//  gentlejogger
//
//  Created by hamer farag on 8/6/18.
//  Copyright © 2018 jim. All rights reserved.
//

import UIKit
import Firebase


private let reuseIdentifier = "cell"


class ReportCollectionViewController: UICollectionViewController, UICollectionViewDelegateFlowLayout {
    var data: [DatabaseCollection ] = [];
    var count = 0;
    var clickedIndexPath :IndexPath? = nil;
    var height = 170;
    override func viewDidLoad() {
        super.viewDidLoad()
        let value = UIInterfaceOrientation.portrait.rawValue
        UIDevice.current.setValue(value, forKey: "orientation")
        
        
        collectionView?.register(UINib(nibName: "ExpandedCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "extendedCell")

        var ref: DatabaseReference!
        
        ref = Database.database().reference()
        
        let userID = Auth.auth().currentUser?.uid
        ref.child("UserHistory").child(userID!).observeSingleEvent(of: .value, with: { (snapshot) in
            // Get user value
            
            for (key,value) in (snapshot.value as? NSDictionary)!{
                self.count+=1;
                self.data.append(DatabaseCollection.init(date: key as! String, dictionary: value as! Dictionary<String, Any>))
            }
                self.data = self.data.sorted(by: { $0.date > $1.date })
             self.collectionView?.reloadData()
        }) { (error) in
            print(error.localizedDescription)
        }
        
        

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
    }
    */

    // MARK: UICollectionViewDataSource

    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }


    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        if((clickedIndexPath) != nil){
            let index:Int = (clickedIndexPath?.item)!
            return data[index].sessions.count;
        }
        return data.count
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
    
        
        if(clickedIndexPath != nil){
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "extendedCell", for: indexPath) as! ExpandedCollectionViewCell
            let index:Int = (clickedIndexPath?.item)!
            
            cell.date.text = data[index].sessions[indexPath.item].time

            let sess:[Session] = data[index].sessions
            
                collectionViewLayout.invalidateLayout()
                cell.stepsLabel.text = sess[indexPath.item].sessionSteps
                cell.timeLabel.text = sess[indexPath.item].sessionTime
                cell.paceLabel.text = sess[indexPath.item].sessionPace
                cell.sessionWalkLabel.text = sess[indexPath.item].sessionWalk
                cell.sessionJogLabel.text = sess[indexPath.item].sessionJog
                cell.sessionRunLabel.text = sess[indexPath.item].sessionRun
                cell.sessionRaceLabel.text = sess[indexPath.item].sessionRace
           
            
                
                

             cell.backButton.addTarget(self, action: #selector(ReportCollectionViewController.buttonClicked), for: .touchUpInside)
            collectionViewLayout.invalidateLayout()
            
            cell.backgroundColor = UIColor.white
            cell.contentView.layer.cornerRadius = 2.0
            cell.contentView.layer.borderWidth = 2.0
            cell.contentView.layer.borderColor = UIColor.clear.cgColor
            cell.contentView.layer.masksToBounds = true;
            
            cell.layer.shadowColor = UIColor.lightGray.cgColor
            cell.layer.shadowOffset = CGSize(width:0,height: 2.0)
            cell.layer.shadowRadius = 2.0
            cell.layer.shadowOpacity = 1.0
            cell.layer.masksToBounds = false;
            cell.layer.shadowPath = UIBezierPath(roundedRect:cell.bounds, cornerRadius:cell.contentView.layer.cornerRadius).cgPath
          
            return cell
        }
        
       
        height = 170;
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! ReportCollectionViewCell
        
        // Configure the cell
        cell.date.text = data[indexPath.item].date
        cell.steps.text = data[indexPath.item].secs
        cell.time.text = data[indexPath.item].time
        cell.pace.text = data[indexPath.item].pace
        
        cell.contentView.layer.cornerRadius = 2.0
        cell.contentView.layer.borderWidth = 1.0
        cell.contentView.layer.borderColor = UIColor.clear.cgColor
        cell.contentView.layer.masksToBounds = true;
        
        cell.layer.shadowColor = UIColor.lightGray.cgColor
        cell.layer.shadowOffset = CGSize(width:0,height: 2.0)
        cell.layer.shadowRadius = 2.0
        cell.layer.shadowOpacity = 1.0
        cell.layer.masksToBounds = false;
        cell.layer.shadowPath = UIBezierPath(roundedRect:cell.bounds, cornerRadius:cell.contentView.layer.cornerRadius).cgPath
    
        return cell
    }
    
    @objc func buttonClicked() {
        clickedIndexPath = nil;
        collectionView?.reloadData()
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if(clickedIndexPath != nil){
            print("Inside Index Path");
            print(height);
            return CGSize(width: collectionView.frame.width*0.8, height: CGFloat(643))
        }
        print("Outside");
        print(height);
        return CGSize(width: 170, height: 170)
    }
    
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if(clickedIndexPath != nil){
            return;
        }
        clickedIndexPath = indexPath;
        collectionView.reloadData()
    }

    // MARK: UICollectionViewDelegate

    /*
    // Uncomment this method to specify if the specified item should be highlighted during tracking
    override func collectionView(_ collectionView: UICollectionView, shouldHighlightItemAt indexPath: IndexPath) -> Bool {
        return true
    }
    */

    /*
    // Uncomment this method to specify if the specified item should be selected
    override func collectionView(_ collectionView: UICollectionView, shouldSelectItemAt indexPath: IndexPath) -> Bool {
        return true
    }
    */

    /*
    // Uncomment these methods to specify if an action menu should be displayed for the specified item, and react to actions performed on the item
    override func collectionView(_ collectionView: UICollectionView, shouldShowMenuForItemAt indexPath: IndexPath) -> Bool {
        return false
    }

    override func collectionView(_ collectionView: UICollectionView, canPerformAction action: Selector, forItemAt indexPath: IndexPath, withSender sender: Any?) -> Bool {
        return false
    }

    override func collectionView(_ collectionView: UICollectionView, performAction action: Selector, forItemAt indexPath: IndexPath, withSender sender: Any?) {
    
    }
    */

}
