//
//  Session.swift
//  gentlejogger
//
//  Created by hamer farag on 8/6/18.
//  Copyright © 2018 jim. All rights reserved.
//

import Foundation

struct Session {
    let time : String;
    let sessionSteps : String;
    let sessionTime : String;
    let sessionPace : String;
    let sessionWalk : String;
    let sessionJog : String;
    let sessionRun : String;
    let sessionRace : String;
    
    init(time: String, dictionary : Dictionary<String,String>){
        print("time = ",time)
        if let endIndex = time.range(of: " ")?.lowerBound {
            self.time = String(time[endIndex...])

        }else{
            self.time = time;
        }
        self.sessionSteps = dictionary["sessionSteps"]!;
        self.sessionTime = dictionary["sessionTime"]!;
        if let endIndex = dictionary["sessionPace"]?.range(of: ".")?.lowerBound {
            self.sessionPace = String(dictionary["sessionPace"]![..<endIndex])
        }else{
            self.sessionPace = dictionary["sessionPace"]!;
        }
        self.sessionWalk = dictionary["walkSteps"]!;
        self.sessionJog = dictionary["jogSteps"]!;
        self.sessionRun = dictionary["runSteps"]!;
        self.sessionRace = dictionary["raceSteps"]!;
    }
}
