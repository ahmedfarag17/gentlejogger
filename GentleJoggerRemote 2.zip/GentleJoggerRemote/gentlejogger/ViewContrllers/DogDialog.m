//
//  DogDialog.m
//  gentlejogger
//
//  Created by mojado on 5/10/17.
//  Copyright © 2017 Sackner Wellness All rights reserved.
//

#import "DogDialog.h"

@implementation DogDialog

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
+ (UIView*) initWithXib:(NSString*)title
{
    UIView * backgroundView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    [backgroundView setBackgroundColor:[UIColor clearColor]];
    
    UIView * alpa_backgroundView = [[UIView alloc] initWithFrame:backgroundView.bounds];
    [alpa_backgroundView setBackgroundColor:[UIColor blackColor]];
    [alpa_backgroundView setAlpha:0.4];
    [backgroundView addSubview:alpa_backgroundView];
    
    DogDialog * dlg = [[[NSBundle mainBundle] loadNibNamed:@"DogDialog" owner:self options:nil] firstObject];
    dlg.layer.cornerRadius = 30;
    dlg.center = backgroundView.center;
    [backgroundView addSubview:dlg];
    [dlg.lbl_title setText:title];
    return backgroundView;
}
- (IBAction)onClickOk:(id)sender {
    [self.superview removeFromSuperview];
}
@end
