//
//  ViewController.m
//  gentlejogger
//
//  Created by mojado on 4/13/17.
//  Copyright © 2017 Sackner Wellness All rights reserved.
//

#import "SetupController.h"
#import "SelectDeviceController.h"
#import "RegistrationController.h"
#import "DeviceMemory.h"
#import "SqlManager.h"
#import "AppDelegate.h"
#import "SqlManager.h"
@import Firebase;

#define LOGOSPACE 50

@interface SetupController ()<UIActionSheetDelegate, UITextFieldDelegate, BluetoothDeviceResultDelegate, UIPickerViewDataSource, UIPickerViewDelegate> {
    
    IBOutlet UIView *mContentContainer;
    IBOutlet UIView *mDailyGoalStepsBottomBar;
    IBOutlet UILabel *mLowDescription;
    
    NSString * m_selectSpeed;
    int        m_selectSteps;
    
    UIImageView * mSetupLogoImageView;
    NSMutableArray * speedArray;
    
    __weak IBOutlet UIView *pickerView;
    
    __weak IBOutlet UIPickerView *walkPicker;
    __weak IBOutlet UIPickerView *jogPicker;
    __weak IBOutlet UIPickerView *runPicker;
    __weak IBOutlet UIPickerView *sprintPicker;
    NSArray * pickerSpeed;
    NSString * intervalType;
    NSString * min;
    NSString * sec;
    
    NSString * alreadyConnectedUUID;
    NSString * alreadyConnectedName;
    BOOL nowScanningForReconnect;
    BOOL nowConnectForReconnect;
    
    BOOL needForReconnect;
}
@property (strong, nonatomic) IBOutlet UIButton *lbl_isConnected;
@property (strong, nonatomic) IBOutlet UIImageView *img_isConnectCheck;
@property (strong, nonatomic) IBOutlet UIButton *lbl_userName;
@property (strong, nonatomic) IBOutlet UILabel *lbl_speed;
@property (strong, nonatomic) IBOutlet UILabel *lbl_goalStep;
@property (strong, nonatomic) IBOutlet UITextField *edt_deviceStep;

@property (strong, nonatomic) IBOutlet UIImageView *logoImageView;
@property (strong, nonatomic) IBOutlet UIButton *btn_simulator;
@property (strong, nonatomic) IBOutlet UIImageView *img_simulatorArrow;

@property (strong, nonatomic) IBOutlet UILabel *pickerLabel;
@property (strong, nonatomic) IBOutlet UIButton *run_simulator;
@property (strong, nonatomic) IBOutlet UIButton *jog_simulator;
@property (strong, nonatomic) IBOutlet UIButton *race_simulator;
@property (strong, nonatomic) IBOutlet UIButton *rest_simulator;
@end

@implementation SetupController

- (void)viewDidAppear:(BOOL)animated{
    [self addLogoImage];
    if (![@"1" isEqualToString:[[NSUserDefaults standardUserDefaults] objectForKey:@"videoValue"]]) {
        NSLog(@"DID NOT OPEN");
        [NSThread detachNewThreadSelector:@selector(performSearch:) toTarget:self withObject:nil];
        
    }
    
    
    
}

-(void)performSearch:(id)sender {
    while (![@"1" isEqualToString:[[NSUserDefaults standardUserDefaults] objectForKey:@"intro"]]) {
        
    }
    NSLog(@"Done");
    [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:@"videoValue"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    NSString * storyboardName = @"Main";
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
    UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"Onboarding Screen"];
    [self presentViewController:vc animated:YES completion:nil];
    // Perform a search operation here
    
    [NSThread exit];
}

- (void)viewDidLoad {
    
    [super viewDidLoad];
    [self.navigationController.navigationBar setHidden:NO];
    
    [self setTitle:@"Settings"];
    speedArray = [[NSMutableArray alloc] initWithObjects:@"Jog",@"Run",@"Race", @"Dash", nil];
    
    pickerSpeed = @[@[@"0", @"1", @"2", @"3", @"4", @"5" ], @[@"Mins"], @[@"00", @"10", @"20", @"30", @"40", @"50" ], @[@"Secs"]];
    
    walkPicker.dataSource = self;
    walkPicker.delegate = self;
    pickerView.hidden = TRUE;
    
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    NSString *textToLoad;
        textToLoad = [prefs stringForKey:@"walkPicker"];
    if(textToLoad == NULL){
        [prefs setObject:@"10" forKey:@"walkPicker"];

    }
        textToLoad = [prefs stringForKey:@"jogPicker"];
    if(textToLoad == NULL){
        [prefs setObject:@"10" forKey:@"jogPicker"];

    }
        textToLoad = [prefs stringForKey:@"runPicker"];
    if(textToLoad == NULL){
        [prefs setObject:@"10" forKey:@"runPicker"];

    }
        textToLoad = [prefs stringForKey:@"racePicker"];
    if(textToLoad == NULL){
        [prefs setObject:@"10" forKey:@"racePicker"];

    }
    
    textToLoad = [prefs stringForKey:@"restPicker"];
    if(textToLoad == NULL){
        [prefs setObject:@"00" forKey:@"restPicker"];
        
    }
        
    
    NSUserDefaults * userDefault = [NSUserDefaults standardUserDefaults];
    NSString * device_speed = [userDefault objectForKey:SYS_KEY_DEVICE_SPEED];
    if(device_speed)
        m_selectSpeed = device_speed;
    else{
        m_selectSpeed = @"Jog";
        [userDefault setValue:m_selectSpeed forKey:SYS_KEY_DEVICE_SPEED];
        [userDefault synchronize];
    }
    [self.lbl_speed setText:m_selectSpeed];
    NSString * device_steps = [userDefault objectForKey:SYS_KEY_DEVICE_STEP];
    if(device_steps)
        m_selectSteps = [device_steps intValue];
    else{
        [userDefault setValue:@"10000" forKey:SYS_KEY_DEVICE_STEP];
        [userDefault synchronize];
        m_selectSteps = 10000;
    }
    [self.edt_deviceStep setText:[NSString stringWithFormat:@"%d",m_selectSteps]];
    
    UIToolbar * toolbar = [[UIToolbar alloc] init];
    [toolbar setBarStyle:UIBarStyleBlackTranslucent];
    [toolbar sizeToFit];
    
    UIBarButtonItem * flexButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:nil];
    UIBarButtonItem * doneButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(onHideKeyboardForDeviceStep)];
    
    NSArray * itemsArray = [NSArray arrayWithObjects:flexButton,doneButton, nil];
    [toolbar setItems:itemsArray];
    [self.edt_deviceStep setInputAccessoryView:toolbar];
    needForReconnect = NO;
    [self initializeExistConnect];
    
    
    [self.btn_simulator setHidden:YES];
#if SIMULATIONDATA
    [self.btn_simulator setHidden:NO];
    [self.img_simulatorArrow setHidden:YES];
#endif
}
- (void) initializeExistConnect
{
    NSUserDefaults * defaultVal = [NSUserDefaults standardUserDefaults];
    alreadyConnectedUUID = [defaultVal objectForKey:SYS_KEY_ALREADYCONNECTED_UUID];
    alreadyConnectedName = [defaultVal objectForKey:SYS_KEY_ALREADYCONNECTED_NAME];
    
    if(alreadyConnectedUUID && alreadyConnectedName){
        nowScanningForReconnect = YES;
        needForReconnect = YES;
        [self.lbl_isConnected setTitle:@"Scanning for reconnect..." forState:UIControlStateNormal];
        [self.img_isConnectCheck setHidden:YES];
        AppDelegate * appdelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
        [appdelegate showLoader];
        [self sendCMDScan];
    }else{
        nowScanningForReconnect = YES;
        needForReconnect = YES;
        [self.lbl_isConnected setTitle:@"Scanning GJ" forState:UIControlStateNormal];
        [self.img_isConnectCheck setHidden:YES];
        AppDelegate * appdelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
        [appdelegate showLoader];
        [self sendCMDScan];

    }
}

// The number of columns of data
- (int)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 4;
}

// The number of rows of data
- (int)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    NSLog(@"Value = %d", (int)[(NSArray*)pickerSpeed[component] count]);
    return (int)[(NSArray*)pickerSpeed[component] count];
}

// The data to return for the row and component (column) that's being passed in
- (NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return pickerSpeed[component][row];
}

// Catpure the picker view selection
//- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
//{
//    // This method is triggered whenever the user makes a change to the picker selection.
//    // The parameter named row and component represents what was selected.
//    //    NSString *str = [pickerSpeed[component][row] substringWithRange: NSMakeRange (0, 2)];;
//    if(component == 0){
//        NSLog(@"Comp 0");
//        min = pickerSpeed[component][row];
//        //        [prefs setObject:str forKey:@"walkPicker"];
//    }else if(component == 2){
//        NSLog(@"Comp 3");
//        sec = pickerSpeed[component][row];
//        //        [prefs setObject:str forKey:@"jogPicker"];
//    }
//    NSLog(@"%@", pickerSpeed[component][row]);
//}

- (IBAction)pickerDone:(id)sender {
    
    long seconds = [pickerSpeed[2][[walkPicker selectedRowInComponent:2]] integerValue];
    long minutes = [pickerSpeed[0][[walkPicker selectedRowInComponent:0]] integerValue];
    NSLog(@"Seconds: %ld  %@ Minutes: %ld",seconds,sec,minutes);
    long total = (minutes*60)+seconds;
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    if([intervalType  isEqual: @"walk"]){
        [prefs setObject:[@(total) stringValue] forKey:@"walkPicker"];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }else if([intervalType  isEqual: @"jog"]){
        [prefs setObject:[@(total) stringValue] forKey:@"jogPicker"];
    }else if([intervalType  isEqual: @"run"]){
        [prefs setObject:[@(total) stringValue] forKey:@"runPicker"];
    }else if([intervalType  isEqual: @"race"]){
        [prefs setObject:[@(total) stringValue] forKey:@"racePicker"];
    }else if([intervalType  isEqual: @"rest"]){
        [prefs setObject:[@(total) stringValue] forKey:@"restPicker"];
    }
    pickerView.hidden = TRUE;
    mSetupLogoImageView.hidden = FALSE;
//    sec = nil;
//    min = nil;
    
}


- (IBAction)clickConnected:(id)sender {
    SelectDeviceController * vc =[self.storyboard instantiateViewControllerWithIdentifier:@"id_SelectDeviceController"];
    [self.navigationController pushViewController:vc animated:YES];
}
- (IBAction)clickRegistration:(id)sender {
    RegistrationController * vc =[self.storyboard instantiateViewControllerWithIdentifier:@"id_RegistrationController"];
    [self.navigationController pushViewController:vc animated:YES];
}
- (IBAction)clickSpeed:(id)sender {
    NSMutableArray * selectableSpeeds = [NSMutableArray new];
    [selectableSpeeds addObject:m_selectSpeed];
    for(NSString * str in speedArray){
        if(![str isEqualToString:m_selectSpeed]){
            [selectableSpeeds addObject:str];
        }
    }
    UIActionSheet * actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:[selectableSpeeds objectAtIndex:0] otherButtonTitles:[selectableSpeeds objectAtIndex:1],[selectableSpeeds objectAtIndex:2],[selectableSpeeds objectAtIndex:3], nil];
    [actionSheet showInView:self.view];
    speedArray = selectableSpeeds;
}
- (IBAction)onClearAllHistory:(id)sender {
    if(![[DeviceMemory createInstance] isConnected]){
        [[[UIAlertView alloc] initWithTitle:nil message:@"Please attach to device first" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil] show];
    }else{
        
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"Do you want to clear the device and all history?" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Ok", nil];
        alertView.tag = 1001;
        [alertView show];
    }
}
- (IBAction)onLoadSimulationData:(id)sender {
//    UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:nil message:@"Are you sure add simulation data?" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Ok", nil];
//    alertView.tag = 1002;
//    [alertView show];
    
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    NSString *textToLoad;
    if(sender == _btn_simulator){
        textToLoad = [prefs stringForKey:@"walkPicker"];
        [_pickerLabel setText:@"Jog Time"];
        intervalType = @"walk";
    }else if(sender == _jog_simulator){
        textToLoad = [prefs stringForKey:@"jogPicker"];
        [_pickerLabel setText:@"Run Time"];
        intervalType = @"jog";
    }else if(sender == _run_simulator){
        textToLoad = [prefs stringForKey:@"runPicker"];
        [_pickerLabel setText:@"Race Time"];
        intervalType = @"run";
    }else if(sender == _race_simulator){
        textToLoad = [prefs stringForKey:@"racePicker"];
        [_pickerLabel setText:@"Dash Time"];
        intervalType = @"race";
    }else if(sender == _rest_simulator){
        textToLoad = [prefs stringForKey:@"restPicker"];
        [_pickerLabel setText:@"Rest Time"];
        intervalType = @"rest";
    }
    NSLog(@"Text to load = %@",textToLoad);
    if(textToLoad != NULL){
        NSInteger count = [textToLoad integerValue];
        NSInteger mins = count/60;
        NSInteger secs = count%60;
        switch (mins) {
            case 0:
                [self->walkPicker selectRow:0 inComponent:0 animated:YES];
                break;
            case 1:
                [self->walkPicker selectRow:1 inComponent:0 animated:YES];
                break;
            case 2:
                [self->walkPicker selectRow:2 inComponent:0 animated:YES];
                break;
            case 3:
                [self->walkPicker selectRow:3 inComponent:0 animated:YES];
                break;
            case 4:
                [self->walkPicker selectRow:4 inComponent:0 animated:YES];
                break;
            case 5:
                [self->walkPicker selectRow:5 inComponent:0 animated:YES];
                break;
            default:
                break;
        }
        
        switch (secs) {
            case 0:
                [self->walkPicker selectRow:0 inComponent:2 animated:YES];
                break;
            case 10:
                [self->walkPicker selectRow:1 inComponent:2 animated:YES];
                break;
            case 20:
                [self->walkPicker selectRow:2 inComponent:2 animated:YES];
                break;
            case 30:
                [self->walkPicker selectRow:3 inComponent:2 animated:YES];
                break;
            case 40:
                [self->walkPicker selectRow:4 inComponent:2 animated:YES];
                break;
            case 50:
                [self->walkPicker selectRow:5 inComponent:2 animated:YES];
                break;
            default:
                break;
        }
    }else{
        
        NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
        if([intervalType  isEqual: @"walk"]){
            [prefs setObject:@"10" forKey:@"walkPicker"];
            [[NSUserDefaults standardUserDefaults] synchronize];
        }else if([intervalType  isEqual: @"jog"]){
            [prefs setObject:@"10" forKey:@"jogPicker"];
        }else if([intervalType  isEqual: @"run"]){
            [prefs setObject:@"10" forKey:@"runPicker"];
        }else if([intervalType  isEqual: @"race"]){
            [prefs setObject:@"10" forKey:@"racePicker"];
        }

        if([intervalType  isEqual: @"rest"]){
            [prefs setObject:@"00" forKey:@"restPicker"];
            [self->walkPicker selectRow:0 inComponent:0 animated:YES];
            [self->walkPicker selectRow:0 inComponent:2 animated:YES];
        }else{
            [self->walkPicker selectRow:0 inComponent:0 animated:YES];
            [self->walkPicker selectRow:1 inComponent:2 animated:YES];
        }
//        min = @"0";
//        sec = @"10";
    }
    pickerView.hidden = FALSE;
    mSetupLogoImageView.hidden = TRUE;
}
- (void) sendCMD:(NSString*)cmdData :(int)cmdIndex
{
#if SIM
#else
    
    
    NSLog(@"send Command \n %@ \n", cmdData);
    
    NSString * device_name = [[DeviceMemory createInstance] deveice_name];
    NSString * device_uuid = [[DeviceMemory createInstance] device_uuidStr];
    
    LogicViewController * m_mainview = ((DeviceMemory*)[DeviceMemory createInstance])._mainViewController;
    m_mainview.ble_delegate = self;
    BLECMD * scanCommand = [BLECMD new];
    scanCommand.cmdStr = CMDSTR_WRITEDATA;
    scanCommand.cmd_id = cmdIndex;
    scanCommand.cmd_waitTime = 40;
    NSMutableDictionary * dict = [NSMutableDictionary new];
    [dict setObject:device_uuid forKey:@"peripheral-identifier-UUIDString"];
    [dict setObject:device_name forKey:@"peripheral-identifier-Name"];
    [dict setObject:cmdData forKey:@"peripheral-write"];
    scanCommand.cmdData = dict;
    [m_mainview sendCMDObject:scanCommand];
#endif
}
- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
    if(alertView.tag == 1001){
        if(buttonIndex == 1){
            [[SqlManager createInstance] removeAllData];
            NSString * cmdData = @"count=0#time=0#";
            [self sendCMD:cmdData :5];
            
            [[[UIAlertView alloc] initWithTitle:nil message:@"All history cleared." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil] show];
        }
    }else if(alertView.tag == 1002){
        if(buttonIndex == 1){
            for(int i=1;i<120;i+=3){
                int count = 500 + rand() % 4500;
                int paces = 120 + rand()% 80;
                int time = (count *  60) / paces;
                [[SqlManager createInstance] insertData:count time:time paces:paces timeSpec:i];
            }
        }
    }
}
- (void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 4)
        return;
    m_selectSpeed = [speedArray objectAtIndex:buttonIndex];
    [self.lbl_speed setText:m_selectSpeed];
    NSUserDefaults * userDefault = [NSUserDefaults standardUserDefaults];
    [userDefault setValue:m_selectSpeed forKey:SYS_KEY_DEVICE_SPEED];
    [userDefault synchronize];
}
- (void)onHideKeyboardForDeviceStep
{
    [self.edt_deviceStep resignFirstResponder];
    m_selectSteps = [self.edt_deviceStep.text intValue];
    NSUserDefaults * userDefault = [NSUserDefaults standardUserDefaults];
    [userDefault setValue:[NSString stringWithFormat:@"%d",m_selectSteps] forKey:SYS_KEY_DEVICE_STEP];
    [userDefault synchronize];
}

- (IBAction)clickDailyGoalSteps:(id)sender {
}



- (void) viewWillAppear:(BOOL)animated {
    [self.navigationController.navigationBar setHidden:YES];
    
    [[DeviceMemory createInstance] setBluetoothDeviceResultReceiver:self];
    if(nowScanningForReconnect){
    }else if(![[DeviceMemory createInstance] isConnected]){
        [self.lbl_isConnected setTitle:@"Tap here to connect." forState:UIControlStateNormal];
        [self.img_isConnectCheck setHidden:YES];
    }else {
        NSString * connectedDeviceName = [[NSUserDefaults standardUserDefaults] objectForKey:SYS_KEY_ALREADYCONNECTED_NAME];
        NSLog(@"---------------------\nsetup connect%@\n----------------",connectedDeviceName);
        [self.lbl_isConnected setTitle:[NSString stringWithFormat:@"Connected - %@",[connectedDeviceName substringFromIndex:2]] forState:UIControlStateNormal];
        [self.img_isConnectCheck setHidden:NO];
    }
    FIRUser *user = [FIRAuth auth].currentUser;
    if (user) {
        [self.lbl_userName setTitle:user.email forState:UIControlStateNormal];

    }else{
        [self.lbl_userName setTitle:@"No User" forState:UIControlStateNormal];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)addLogoImage {
    if(mSetupLogoImageView == nil) {
        int y = mDailyGoalStepsBottomBar.frame.origin.y + mDailyGoalStepsBottomBar.frame.size.height + LOGOSPACE;
        int height = mLowDescription.frame.origin.y - y - LOGOSPACE;
        int width = height * 584.f/394.f;//mContentContainer.frame.size.width - x * 2 ;
        
        int x = (mContentContainer.frame.size.width - width)/2;
        y += 20;
        
        mSetupLogoImageView = [[UIImageView alloc] initWithFrame:CGRectMake(x, y, width,height)];
        [mSetupLogoImageView setImage:[UIImage imageNamed:@"setup_logo_trim.png"]];
        [mSetupLogoImageView setContentMode:UIViewContentModeScaleAspectFill];
        [mContentContainer addSubview:mSetupLogoImageView];
    }
}

- (IBAction)signOut:(id)sender {
    NSError *signOutError;
    BOOL status = [[FIRAuth auth] signOut:&signOutError];
    if (!status) {
        NSLog(@"Error signing out: %@", signOutError);
        return;
    }
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:
                                @"Main" bundle:[NSBundle mainBundle]];
    UIViewController *myController = [storyboard instantiateViewControllerWithIdentifier:@"loginController"];
    [self presentViewController:myController animated:YES completion:nil];
    
}

- (IBAction)onDisconnect:(id)sender {
    
    [[DeviceMemory createInstance] setBluetoothDeviceResultReceiver:self];
    
    NSString * device_name = [[DeviceMemory createInstance] deveice_name];
    NSString * device_uuid = [[DeviceMemory createInstance] device_uuidStr];
    
    LogicViewController * m_mainview = ((DeviceMemory*)[DeviceMemory createInstance])._mainViewController;
    BLECMD * scanCommand = [BLECMD new];
    scanCommand.cmdStr = CMDSTR_DISCONNECTDEVICE;
    scanCommand.cmd_id = 10;
    scanCommand.cmd_waitTime = 10;
    NSMutableDictionary * dict = [NSMutableDictionary new];
    [dict setObject:device_uuid forKey:@"peripheral-identifier-UUIDString"];
    [dict setObject:device_name forKey:@"peripheral-identifier-Name"];
    scanCommand.cmdData = dict;
    [m_mainview sendCMDObject:scanCommand];
}
- (void) sendCMDScan
{
    [[DeviceMemory createInstance] setBluetoothDeviceResultReceiver:self];
    
    LogicViewController * m_mainview = ((DeviceMemory*)[DeviceMemory createInstance])._mainViewController;
    BLECMD * scanCommand = [BLECMD new];
    scanCommand.cmdStr = CMDSTR_SCANDEVICE;
    scanCommand.cmd_id = 999;
    scanCommand.cmd_waitTime = 5;
    [m_mainview sendCMDObject:scanCommand];
    
}
- (void) sendCMDConnect:(NSString*)deviceName :(NSString*)deviceUUID
{
    
    alreadyConnectedUUID = deviceUUID;
    alreadyConnectedName = deviceName;
    [self performSelector:@selector(connectFunction) withObject:nil afterDelay:5.f];
    
    

}
- (void) connectFunction
{
    LogicViewController * m_mainview = ((DeviceMemory*)[DeviceMemory createInstance])._mainViewController;
    BLECMD * scanCommand = [BLECMD new];
    scanCommand.cmdStr = CMDSTR_CONNECTDEVICE;
    scanCommand.cmd_id = 1000;
    scanCommand.cmd_waitTime = 5;
    NSMutableDictionary * dict = [NSMutableDictionary new];
    [dict setObject:alreadyConnectedUUID forKey:@"peripheral-identifier-UUIDString"];
    [dict setObject:alreadyConnectedName forKey:@"peripheral-identifier-Name"];
    scanCommand.cmdData = dict;
    [m_mainview sendCMDObject:scanCommand];
    
    NSUserDefaults * defaultVal = [NSUserDefaults standardUserDefaults];
    [defaultVal setObject:alreadyConnectedUUID forKey:SYS_KEY_ALREADYCONNECTED_UUID];
    [defaultVal setObject:alreadyConnectedName forKey:SYS_KEY_ALREADYCONNECTED_NAME];
    [defaultVal synchronize];
    
    [[DeviceMemory createInstance] setDevice_uuidStr:alreadyConnectedUUID];
    [[DeviceMemory createInstance] setDeveice_name:alreadyConnectedName];
    
    
    
    NSLog(@"---------------------\nAUTO FIND connect%@\n----------------",alreadyConnectedName);
}
- (void) sendCMDNotifySet
{
    if(alreadyConnectedUUID && alreadyConnectedName){
        LogicViewController * m_mainview = ((DeviceMemory*)[DeviceMemory createInstance])._mainViewController;
        m_mainview.ble_delegate = self;
        BLECMD * scanCommand = [BLECMD new];
        scanCommand.cmdStr = CMDSTR_NOTIFY;
        scanCommand.cmd_id = 100;
        scanCommand.cmd_waitTime = 40;
        NSMutableDictionary * dict = [NSMutableDictionary new];
        [dict setObject:alreadyConnectedUUID forKey:@"peripheral-identifier-UUIDString"];
        [dict setObject:alreadyConnectedName forKey:@"peripheral-identifier-Name"];
        scanCommand.cmdData = dict;
        [m_mainview sendCMDObject:scanCommand];
        
        if(needForReconnect){
            [[DeviceMemory createInstance] setDevice_uuidStr:alreadyConnectedUUID];
            [[DeviceMemory createInstance] setDeveice_name:alreadyConnectedName];
            [[DeviceMemory createInstance] setIsConnected:YES];
        }
        needForReconnect = NO;
        ////// go to dashboard page //////
        [self.navigationController.tabBarController setSelectedIndex:1];
    }
}

- (void) disconnectedFromDevice
{
    
    [[DeviceMemory createInstance] setIsConnected:NO];
    if(self){
        [self.lbl_isConnected setTitle:@"Tap here to connect." forState:UIControlStateNormal];
        [self.img_isConnectCheck setHidden:YES];
    }
}
- (void) connectedToDevice
{
    [[DeviceMemory createInstance] setIsConnected:YES];
    if(self){
        NSString * connectedDeviceName = [[NSUserDefaults standardUserDefaults] objectForKey:SYS_KEY_ALREADYCONNECTED_NAME];
        [self.lbl_isConnected setTitle:[NSString stringWithFormat:@"Connected - %@",[connectedDeviceName substringFromIndex:2]] forState:UIControlStateNormal];
        [self.img_isConnectCheck setHidden:NO];
    }
}

- (void)BluetoothDeviceResult:(BLERESP*)response
{
    if([response.function isEqualToString:@"didDiscoverPeripheral"]){
        NSString * deviceName = [(NSDictionary*)response.message objectForKey:@"peripheral-name"];
        NSString * deviceUUID = [(NSDictionary*)response.message objectForKey:@"peripheral-identifier-UUIDString"];
        
        nowScanningForReconnect = NO;
        nowConnectForReconnect = NO;
        [self.lbl_isConnected setTitle:@"Tap here to connect." forState:UIControlStateNormal];
        AppDelegate * appdelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
        [appdelegate hideLoader];
        
        if(deviceName && deviceName.length > 0){
            if([alreadyConnectedUUID isEqualToString:deviceUUID]){
                if([alreadyConnectedName isEqualToString:deviceName]){
                    /// go to connect
                    nowScanningForReconnect = YES;
                    nowConnectForReconnect = YES;
                    [self.lbl_isConnected setTitle:@"Now Connecting..." forState:UIControlStateNormal];
                    [self sendCMDConnect:deviceName :deviceUUID];
                }
            }else{
                nowConnectForReconnect = NO;
            }
        }
    }else if([response.function isEqualToString:@"didConnectPeripheral"]){
        AppDelegate * appdelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
        [appdelegate hideLoader];
        if(response.messageType == 0)/// return connect error
        {
            [[[UIAlertView alloc] initWithTitle:nil message:@"Device connect fail." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil] show];
        }else{
            nowScanningForReconnect = NO;
            nowConnectForReconnect = NO;
            
            [[DeviceMemory createInstance] setIsConnected:YES];
            
            NSString * connectedDeviceName = [[NSUserDefaults standardUserDefaults] objectForKey:SYS_KEY_ALREADYCONNECTED_NAME];
            [self.lbl_isConnected setTitle:[NSString stringWithFormat:@"Connected - %@",[connectedDeviceName substringFromIndex:2]] forState:UIControlStateNormal];
            [self.img_isConnectCheck setHidden:NO];
            [self sendCMDNotifySet];
        }
    }else if([response.function isEqualToString:@"didDisconnectPeripheral"]){
        [self disconnectedFromDevice];
        //        [[[UIAlertView alloc] initWithTitle:nil message:@"Device disconnected." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil] show];
    }else if([response.function isEqualToString:@"endCMD"]){
        if([response.message intValue] == 999){
            if(!nowConnectForReconnect){
                
                LogicViewController * m_mainview = ((DeviceMemory*)[DeviceMemory createInstance])._mainViewController;
                NSMutableArray *  device_array = [m_mainview getDeviceList];
                if(device_array.count == 1){
                    if(!(nowScanningForReconnect && nowConnectForReconnect)){
                        NSDictionary * device  = [device_array objectAtIndex:0];
                        NSString * deviceUUID = [device objectForKey:@"peripheral-identifier-UUIDString"];
                        NSString * deviceName = [device objectForKey:@"peripheral-name"];
                        nowScanningForReconnect = YES;
                        nowConnectForReconnect = YES;
                        [self.lbl_isConnected setTitle:[NSString stringWithFormat:@"Now Connecting to %@",[deviceName substringFromIndex:2]] forState:UIControlStateNormal];
                        [self sendCMDConnect:deviceName :deviceUUID];
                        return;
                    }
                }
                nowScanningForReconnect = NO;
                nowConnectForReconnect = NO;
                [self.lbl_isConnected setTitle:@"Tap here to connect." forState:UIControlStateNormal];
                AppDelegate * appdelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
                [appdelegate hideLoader];
                
            }
        }else if([response.message intValue] == 1000){
            nowScanningForReconnect = NO;
            nowConnectForReconnect = NO;
            [self.lbl_isConnected setTitle:@"Tap here to connect." forState:UIControlStateNormal];
            AppDelegate * appdelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
            [appdelegate hideLoader];
        }
    }
}
- (BOOL)shouldAutorotate {
    return NO;
}
@end
