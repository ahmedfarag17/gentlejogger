//
//  DataBaseItem.m
//  gentlejogger
//
//  Created by mojado on 4/24/17.
//  Copyright © 2017 Sackner Wellness All rights reserved.
//

#import "DataBaseItem.h"

@implementation DataBaseItem
- (void) initialDateInfo
{
    NSDate * currentData = [NSDate new];
    NSDateFormatter * formatter  = [NSDateFormatter new];
    [formatter setDateFormat:@"MMM dd, yyyy"];
    currentData = [formatter dateFromString:self.date];
    self.dateVal = currentData;
    NSCalendar * calendar = [NSCalendar currentCalendar];
    NSDateComponents * dateComponent = [calendar components:NSCalendarUnitDay|NSCalendarUnitMonth|NSCalendarUnitYear|NSCalendarUnitWeekOfMonth|NSCalendarUnitWeekOfYear fromDate:currentData];
    self.yearNumber = (int)dateComponent.year;
    self.monthNumber = (int)dateComponent.month;
    self.dayNum = (int)dateComponent.day;
    self.weekNum = (int)dateComponent.weekOfYear;
    self.weekNumMonth = (int)dateComponent.weekOfMonth;
}
/*
 @property (atomic) NSString * date;
 @property (atomic) int steps;
 @property (atomic) int secs;
 @property (atomic) int pace;
 */
+(id)createEmptyItemAtDate:(NSDate*)date
{
    DataBaseItem * item = [DataBaseItem new];
    item.steps = 0;
    item.secs = 0;
    item.pace = 0;
    NSDateFormatter * formatter  = [NSDateFormatter new];
    [formatter setDateFormat:@"MMM dd, yyyy"];
    item.date = [formatter stringFromDate:date];
    [item initialDateInfo];
    return item;
}
+ (NSDate*) getBeforeMonthDate:(NSDate*)date :(int)deleteVal
{
    NSCalendar * calendar = [NSCalendar currentCalendar];
    NSDateComponents * dateComponent = [calendar components:NSCalendarUnitDay|NSCalendarUnitMonth|NSCalendarUnitYear|NSCalendarUnitWeekOfMonth|NSCalendarUnitWeekOfYear fromDate:date];
    int yearNumber = (int)dateComponent.year;
    int monthNumber = (int)dateComponent.month;
    if(monthNumber <= deleteVal){
        monthNumber = 12 + monthNumber - deleteVal;
        yearNumber -= 1;
    }else{
        monthNumber -= deleteVal;
    }
    dateComponent.year = yearNumber;
    dateComponent.month = monthNumber;
    dateComponent.day = 1;
    return [calendar dateFromComponents:dateComponent];
}
@end
