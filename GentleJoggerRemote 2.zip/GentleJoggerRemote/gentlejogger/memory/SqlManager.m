//
//  SqlManager.m
//  gentlejogger
//
//  Created by mojado on 4/24/17.
//  Copyright © 2017 Sackner Wellness All rights reserved.
//

#import "SqlManager.h"
#import "sqlite3.h"
#import "DataBaseItem.h"
#import "CommonAPI.h"

@interface SqlManager ()
{
    sqlite3_stmt * saved_resultado;
}
@end

@implementation SqlManager
static SqlManager * _connecter;

+ (id) createInstance
{
    if(!_connecter)
        _connecter = [SqlManager new];
    [_connecter prepareDatabaseFile];
    [_connecter createTable];
    return _connecter;
}
- (void) prepareDatabaseFile
{
    NSString * srcPath = [[NSBundle mainBundle] pathForResource:@"Database" ofType:@"sqlite" inDirectory:nil forLocalization:nil];
    NSFileManager * fileManager = [NSFileManager defaultManager];
    NSError * error;
    NSString * appDatabaseFile = [self databaseFilePath];
    if(![fileManager fileExistsAtPath:appDatabaseFile]){
        [fileManager copyItemAtPath:srcPath toPath:appDatabaseFile error:&error];
    }
}
- (NSString*) databaseFilePath
{
    NSArray * paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString * documentsDirectory = [paths objectAtIndex:0];
    NSString * appDatabaseFile = [documentsDirectory stringByAppendingPathComponent:@"appDB"];
    return appDatabaseFile;
}
- (void) executeSentence:(NSString*) sentence sentenceIsSelect:(BOOL)isSelect{
    static sqlite3 * db;
    sqlite3_stmt * resultado;
    const char * siguiente;
    
    if(!sentence)
        return;
    
    NSString * path = [self databaseFilePath];
    NSData * strData = [sentence dataUsingEncoding:NSUTF8StringEncoding];
    
    if(sqlite3_open([path UTF8String], &db) == SQLITE_OK){
        if(isSelect){
            if(sqlite3_prepare(db, [sentence UTF8String], [strData length], &resultado, &siguiente) == SQLITE_OK){
                saved_resultado = resultado;
            }else{
                NSLog(@"%@",sentence);
                NSLog(@"Error (sqlite3_step): %s", sqlite3_errmsg(db));
            }
        }else{
            if(sqlite3_prepare_v2(db, [sentence UTF8String], [strData length], &resultado, &siguiente)== SQLITE_OK){
                sqlite3_step(resultado);
                sqlite3_finalize(resultado);
            }else{
                NSLog(@"%@",sentence);
                NSLog(@"Error (sqlite3_step): %s", sqlite3_errmsg(db));
            }
        }
    }
    sqlite3_close(db);
}
- (void) createTable
{
    NSString * query = @"CREATE TABLE IF NOT EXISTS tbl_result (result_date TEXT, steps INTEGER, time INTEGER, pace INTEGER, dateTimeinterval LONG)";
    [self executeSentence:query sentenceIsSelect:NO];
}
- (DataBaseItem*) getResultForDate:(NSString*)date
{
    DataBaseItem * resultItem = nil;
    NSString * query = [NSString stringWithFormat:@"select * from tbl_result where result_date = '%@'",date];
    [self executeSentence:query sentenceIsSelect:YES];
    if(saved_resultado){
        while (sqlite3_step(saved_resultado) == SQLITE_ROW) {
            
            resultItem = [DataBaseItem new];
            resultItem.date = [NSString stringWithUTF8String:(char*)sqlite3_column_text(saved_resultado, 0)];
            resultItem.steps = sqlite3_column_int(saved_resultado, 1);
            resultItem.secs = sqlite3_column_int(saved_resultado, 2);
            resultItem.pace = sqlite3_column_int(saved_resultado, 3);
            [resultItem initialDateInfo];
        }
    }
    return resultItem;
}
- (NSMutableArray *) getResultArrayForDaily
{
    NSMutableArray * result = [NSMutableArray new];
    NSString * query = [NSString stringWithFormat:@"select * from tbl_result ORDER BY dateTimeinterval DESC"];
    [self executeSentence:query sentenceIsSelect:YES];
    if(saved_resultado){
        while (sqlite3_step(saved_resultado) == SQLITE_ROW) {
            DataBaseItem * resultItem = [DataBaseItem new];
            resultItem.date = [NSString stringWithUTF8String:(char*)sqlite3_column_text(saved_resultado, 0)];
            resultItem.steps = sqlite3_column_int(saved_resultado, 1);
            resultItem.secs = sqlite3_column_int(saved_resultado, 2);
            resultItem.pace = sqlite3_column_int(saved_resultado, 3);
            [resultItem initialDateInfo];
            [result addObject:resultItem];
        }
    }
    return result;
}
- (NSMutableArray*) getWeeklyData
{
    NSMutableArray * dataArray = [self getResultArrayForDaily];
    NSMutableArray * newDataArray = [NSMutableArray new];
    for(int i=0;i<[dataArray count];i++){
        if(i == 0) [newDataArray addObject:[dataArray firstObject]];
        else{
            DataBaseItem * srcItem = [dataArray objectAtIndex:i];
            DataBaseItem * dscItem = [newDataArray lastObject];
            if(srcItem.yearNumber == dscItem.yearNumber && srcItem.weekNum == dscItem.weekNum){
                int m_steps = srcItem.steps + dscItem.steps;
                int m_secs  = srcItem.secs  + dscItem.secs;
                int m_pace = (m_steps * 60)/ m_secs;
                dscItem.steps = m_steps;
                dscItem.secs = m_secs;
                dscItem.pace = m_pace;
            }else{
                [newDataArray addObject:srcItem];
            }
        }
    }
    return newDataArray;
}
- (NSMutableArray*) getMonthlyData
{
    NSMutableArray * dataArray = [self getResultArrayForDaily];
    NSMutableArray * newDataArray = [NSMutableArray new];
    for(int i=0;i<[dataArray count];i++){
        if(i == 0) [newDataArray addObject:[dataArray firstObject]];
        else{
            DataBaseItem * srcItem = [dataArray objectAtIndex:i];
            DataBaseItem * dscItem = [newDataArray lastObject];
            if(srcItem.yearNumber == dscItem.yearNumber && srcItem.monthNumber == dscItem.monthNumber){
                int m_steps = srcItem.steps + dscItem.steps;
                int m_secs  = srcItem.secs  + dscItem.secs;
                int m_pace = (m_steps * 60)/ m_secs;
                dscItem.steps = m_steps;
                dscItem.secs = m_secs;
                dscItem.pace = m_pace;
            }else{
                [newDataArray addObject:srcItem];
            }
        }
    }
    return newDataArray;
}
- (void) insertData:(int)steps time:(int)secs paces:(int)pace
{
    DataBaseItem * resultItem = [self getResultForDate:[CommonAPI dateString:[NSDate date]]];
    NSString * query = @"";
    if(resultItem){
        int m_steps = steps;
        int m_secs  = secs;
        int m_pace = (m_steps * 60)/ m_secs;
        query = [NSString stringWithFormat:@"UPDATE tbl_result SET steps = %d, time = %d, pace = %d where result_date = '%@'",
                 m_steps, m_secs, m_pace, [CommonAPI dateString:[NSDate date]]];
    }else{
        query = [NSString stringWithFormat:@"INSERT INTO tbl_result (result_date, steps, time, pace, dateTimeinterval) values('%@', %d, %d, %d, %f)",
                 [CommonAPI dateString:[NSDate date]], steps, secs, pace, [[NSDate date] timeIntervalSince1970]];
    }
    [self executeSentence:query sentenceIsSelect:NO];
}
- (void) insertData:(int)steps time:(int)secs paces:(int)pace timeSpec:(int)day
{
    NSDate * specDate = [NSDate dateWithTimeIntervalSinceNow: - (day*24*3600)];
    DataBaseItem * resultItem = [self getResultForDate:[CommonAPI dateString:specDate]];
    NSString * query = @"";
    if(resultItem){
        int m_steps = steps;
        int m_secs  = secs;
        int m_pace = (m_steps * 60)/ m_secs;
        query = [NSString stringWithFormat:@"UPDATE tbl_result SET steps = %d, time = %d, pace = %d where result_date = '%@'",
                 m_steps, m_secs, m_pace, [CommonAPI dateString:specDate]];
    }else{
        query = [NSString stringWithFormat:@"INSERT INTO tbl_result (result_date, steps, time, pace, dateTimeinterval) values('%@', %d, %d, %d, %f)",
                 [CommonAPI dateString:specDate], steps, secs, pace, [specDate timeIntervalSince1970]];
    }
    [self executeSentence:query sentenceIsSelect:NO];
}
- (DataBaseItem *) getTodayResult
{
    DataBaseItem * resultItem = [self getResultForDate:[CommonAPI dateString:[NSDate date]]];
    return resultItem;
}

- (void) removeAllData
{
    NSString * query = @"delete from tbl_result";
    [self executeSentence:query sentenceIsSelect:NO];
    
    
}
@end
