//
//  DeviceMemory.m
//  BluetoothManager
//
//  Created by Robert Mosko on 11/20/16.
//  Copyright © 2016 Sackner Wellness. All rights reserved.
//

#import "DeviceMemory.h"

@implementation DeviceMemory
static DeviceMemory * _deviceMemory;

+(id) createInstance
{
    if(!_deviceMemory)
        _deviceMemory = [DeviceMemory new];
    return _deviceMemory;
}
@end
