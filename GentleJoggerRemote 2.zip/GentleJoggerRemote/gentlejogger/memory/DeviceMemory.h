//
//  DeviceMemory.h
//  BluetoothManager
//
//  Created by Robert Mosko on 11/20/16.
//  Copyright © 2016 Sackner Wellness. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LogicViewController.h"
#import "SetupController.h"

#define USER_KEY_FIRST_NAME  @"firstname"
#define USER_KEY_LAST_NAME   @"lastname"
#define USER_KEY_ORG_NAME    @"organization"
#define USER_KEY_ADD1_NAME   @"address1"
#define USER_KEY_ADD2_NAME   @"address2"
#define USER_KEY_CITY_NAME   @"city"
#define USER_KEY_STATE_NAME  @"state"
#define USER_KEY_ZIP_NAME    @"zip"
#define USER_KEY_EMAIL_NAME  @"email"
#define USER_KEY_IS_REGISTED @"registed"

#define SYS_KEY_DEVICE_SPEED @"speed"
#define SYS_KEY_DEVICE_STEP  @"step"


#define SYS_KEY_ALREADYCONNECTED_UUID   @"alreadyConnectedUUID"
#define SYS_KEY_ALREADYCONNECTED_NAME   @"alreadyConnectedName"

@interface DeviceMemory : NSObject
@property (nonatomic, retain) NSString * device_uuidStr;
@property (nonatomic, retain) NSString * deveice_name;

@property (nonatomic, retain) LogicViewController * _mainViewController;
@property (nonatomic, retain) SetupController     * _setupViewController;
@property (nonatomic, retain) id BluetoothDeviceResultReceiver;

@property (atomic) BOOL isConnected;

@property (atomic) BOOL lockForTab;

+(id) createInstance;
@end
