//
//  SqlManager.h
//  gentlejogger
//
//  Created by mojado on 4/24/17.
//  Copyright © 2017 Sackner Wellness All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DataBaseItem.h"
#import <UIKit/UIKit.h>

@interface SqlManager : NSObject

+ (id) createInstance;
- (void) insertData:(int)steps time:(int)secs paces:(int)pace;
- (void) insertData:(int)steps time:(int)secs paces:(int)pace timeSpec:(int)day;
- (DataBaseItem *) getTodayResult;
- (NSMutableArray *) getResultArrayForDaily;
- (NSMutableArray*) getWeeklyData;
- (NSMutableArray*) getMonthlyData;


- (void) removeAllData;
@end
