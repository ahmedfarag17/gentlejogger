//
//  DataBaseItem.h
//  gentlejogger
//
//  Created by mojado on 4/24/17.
//  Copyright © 2017 Sackner Wellness All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DataBaseItem : NSObject
@property (atomic) NSString * date;
@property (atomic) NSDate * dateVal;
@property (atomic) int steps;
@property (atomic) int secs;
@property (atomic) int pace;
@property (atomic) int yearNumber;
@property (atomic) int monthNumber;
@property (atomic) int weekNum;
@property (atomic) int weekNumMonth;
@property (atomic) int dayNum;

- (void) initialDateInfo;

+(id)createEmptyItemAtDate:(NSDate*)date;
+ (NSDate*) getBeforeMonthDate:(NSDate*)date :(int)deleteVal;
@end
