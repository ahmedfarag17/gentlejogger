//
//  CommonAPI.h
//  BluetoothConnector
//
//  Created by Robert Mosko on 11/15/16.
//  Copyright © 2016 Sackner Wellness All rights reserved.
//

#import <Foundation/Foundation.h>


@interface CommonAPI : NSObject
+ (NSString*) createJsonFromDictionary:(NSDictionary*)dict;
+ (NSDictionary*) createDictFromJson:(NSString*)json;

+(NSString *) convertSecondToTime:(int)second;
+(NSString *) convertSecondToTimeWithOutString:(int)second;


+(void) saveStringToLocal:(NSString*)value keyString:(NSString*)key;
+(NSString *) getLocalValeuForKey:(NSString*) key;


+ (void) setTodayCountATime:(int)count;
+ (void) setTodayTimeACount:(int)count;
+ (void) resetTodayCountATime;


+ (NSString*) dateString:(NSDate*)date;
+ (NSString*) getWeekStartDateFrom:(int)year weekNumOfYear:(int)week;
+ (NSString*) getWeekStartMonthDateFrom:(int)year weekNumOfYear:(int)week;
@end
