//
//  CommonAPI.m
//  BluetoothConnector
//
//  Created by Robert Mosko on 11/15/16.
//  Copyright © 2016 Sackner Wellness All rights reserved.
//

#import "CommonAPI.h"
#import <SBJson/SBJson5.h>

@implementation CommonAPI
+ (NSString*) createJsonFromDictionary:(NSDictionary*)dict
{
    SBJson5Writer * writer = [SBJson5Writer new];
    return [writer stringWithObject:dict];
}
+ (NSDictionary*) createDictFromJson:(NSString*)json
{
    NSError * error = nil;
    NSData * data = [json dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary * dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error];
    return dict;
}
+(NSString *) convertSecondToTime:(int)second
{
    int hour = second / 3600;
    int min = (second % 3600) / 60;
    int sec = second % 60;
    
    return [NSString stringWithFormat:@"%.2d:%.2d:%.2d", hour, min, sec];
}
+(NSString *) convertSecondToTimeWithOutString:(int)second
{
    int hour = second / 3600;
    int min = (second % 3600) / 60;
    int sec = second % 60;
    
    if(hour == 0)
        return [NSString stringWithFormat:@"%.2d:%.2d", min, sec];
    return [NSString stringWithFormat:@"%.2d:%.2d:%.2d", hour, min, sec];
}

+(void) saveStringToLocal:(NSString*)value keyString:(NSString*)key
{
    NSUserDefaults * defaultSaver = [NSUserDefaults standardUserDefaults];
    [defaultSaver setValue:value forKey:key];
    [defaultSaver synchronize];
}

+(NSString *) getLocalValeuForKey:(NSString*) key
{
    NSUserDefaults * defaultSaver = [NSUserDefaults standardUserDefaults];
    return [defaultSaver objectForKey:key];
}

+ (void) setTodayCountATime:(int)count
{
    NSUserDefaults * defaultSaver = [NSUserDefaults standardUserDefaults];
    [defaultSaver setInteger:count  forKey:@"KEY_COUNT"];
    [defaultSaver synchronize];
}
+ (void) setTodayTimeACount:(int)count
{
    NSUserDefaults * defaultSaver = [NSUserDefaults standardUserDefaults];
    [defaultSaver setInteger:count  forKey:@"KEY_TIME"];
    [defaultSaver synchronize];
}
+ (void) resetTodayCountATime
{
    NSUserDefaults * defaultSaver = [NSUserDefaults standardUserDefaults];
    [defaultSaver setInteger:0  forKey:@"KEY_COUNT"];
    [defaultSaver setInteger:0  forKey:@"KEY_TIME"];
    [defaultSaver synchronize];
}


+ (NSString*) dateString:(NSDate*)date
{
    NSDateFormatter * formatter  = [NSDateFormatter new];
    [formatter setDateFormat:@"MMM dd, yyyy"];
    return [formatter stringFromDate:date];
}
+ (NSString*) getWeekStartDateFrom:(int)year weekNumOfYear:(int)week
{
    NSCalendar * calendar = [NSCalendar currentCalendar];
    NSDateComponents * edgecase = [NSDateComponents new];
    [edgecase setYear:year];
    [edgecase setWeekOfYear:week];
    [edgecase setWeekday:1];
    
    NSDate * edgeCaseDate = [calendar dateFromComponents:edgecase];
    
    NSDateFormatter * formatter  = [NSDateFormatter new];
    [formatter setDateFormat:@"MMM dd, yyyy"];
    return [formatter stringFromDate:edgeCaseDate];
}
+ (NSString*) getWeekStartMonthDateFrom:(int)year weekNumOfYear:(int)week
{
    NSCalendar * calendar = [NSCalendar currentCalendar];
    NSDateComponents * edgecase = [NSDateComponents new];
    [edgecase setYear:year];
    [edgecase setWeekOfYear:week];
    [edgecase setWeekday:1];
    
    NSDate * edgeCaseDate = [calendar dateFromComponents:edgecase];
    
    NSDateFormatter * formatter  = [NSDateFormatter new];
    [formatter setDateFormat:@"MMM dd"];
    return [formatter stringFromDate:edgeCaseDate];
}
@end
