//
//  BLECommand.h
//  BluetoothConnector
//
//  Created by Robert Mosko on 11/14/16.
//  Copyright © 2016 Sackner Wellness All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BLECMD.h"
#import "BLEManager.h"
#import "WebService.h"

@interface BLECommand : NSObject
- (void) execCommand:(BLECMD*)cmd;
@end
