//
//  BLERESP.m
//  BluetoothManager
//
//  Created by Robert Mosko on 11/20/16.
//  Copyright © 2016 Sackner Wellness. All rights reserved.
//

#import "BLERESP.h"

@implementation BLERESPONSE_State

@end
