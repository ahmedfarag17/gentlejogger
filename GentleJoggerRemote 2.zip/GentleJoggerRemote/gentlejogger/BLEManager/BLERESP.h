//
//  BLERESP.h
//  BluetoothManager
//
//  Created by Robert Mosko on 11/20/16.
//  Copyright © 2016 Sackner Wellness. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BLERESPONSE_State : NSObject
@property (atomic) int time;
@property (atomic) int reset;
@property (atomic) int speed;
@property (atomic) int duration;
@property (atomic) int steps;
@property (atomic) int count;
@property (atomic) int motor;
@property (atomic) int avgspeed;
@property (atomic) int powerUp;
@end
