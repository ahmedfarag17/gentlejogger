//
//  RootCAAFSecurityPolicy.h
//  tablenow.online
//
//  Created by user1 on 10/3/16.
//  Copyright © 2016 swis.online. All rights reserved.
//

#import "AFSecurityPolicy.h"

@interface RootCAAFSecurityPolicy : AFSecurityPolicy

@end
